# AlexHV Full Bootstrap — Intel CPU + AMD GPU — v0.4

Objetivo desta versão: em um Proxmox VE recém-instalado, executar praticamente
todo o provisionamento do AlexHV com um único fluxo e lançar o instalador do
Windows 11 diretamente no monitor ligado à GPU AMD.

## Escopo

Validado/construído para a combinação atualmente testada:

- CPU/plataforma Intel;
- VT-x + VT-d/IOMMU;
- GPU AMD;
- Proxmox VE;
- uma workstation Windows 11 principal.

Perfis AMD CPU e NVIDIA ficam para versões posteriores.

## Comando principal

```bash
chmod +x install.sh
./install.sh --full
```

O instalador copia o AlexHV para `/opt/alexhv`, cria o comando global `alexhv`
e executa o bootstrap.

Se IOMMU precisar ser habilitado, o AlexHV instala um serviço de retomada,
reinicia o Proxmox e continua após o boot.

## ISO do Windows

O AlexHV usa SOMENTE:

1. `Win11.iso` já existente no storage `local`; ou
2. um link direto oficial Microsoft informado em `WINDOWS_ISO_URL`.

Se nenhum dos dois existir, ele pausa de forma segura. Faça download pela página
oficial da Microsoft, envie a ISO ao Proxmox como `Win11.iso` e execute:

```bash
alexhv resume --apply
```

Não há mecanismo de ativação/bypass de licença neste pacote.

## Licença

O Windows Setup continua visível no monitor físico. Você pode:

- informar sua chave durante a instalação; ou
- escolher que não possui uma chave e ativar depois no próprio Windows.

## Disco

Em instalação limpa, o AlexHV consolida o `local-lvm` vazio no filesystem root
e habilita o storage `local` para imagens, ISO, templates, backups, containers,
snippets e import.

Política de reserva do espaço útil:

- até 400 GiB: host = 20%;
- acima de 400 até 900 GiB: host = 5%;
- acima de 900 GiB: host = 2,5%.

O restante seguro vira o disco virtual do Windows, sem overprovisioning
intencional.

O Windows 11 UEFI sempre cria pequenas partições ocultas EFI/MSR/Recovery.
O volume principal C: recebe o restante do disco virtual.

## Vídeo e entrada

Antes do primeiro boot da VM o AlexHV:

- anexa a GPU AMD e as funções PCI do mesmo slot;
- usa `x-vga=1`;
- define `vga: none`;
- detecta mouse/teclado USB e os anexa à VM;
- pode anexar o áudio onboard Intel isolado.

Resultado esperado:

```text
Power / start VM
       ↓
GPU AMD física
       ↓
monitor físico
       ↓
Windows Setup
```

A interface noVNC não é necessária no fluxo normal.

## Depois de instalar o Windows

Instale `virtio-win-guest-tools.exe` pelo CD VirtIO e o driver AMD.

Depois execute no Proxmox:

```bash
alexhv finalize --apply
```

Isso:

- confirma QEMU Guest Agent quando disponível;
- desativa hibernação/Fast Startup via guest agent;
- ejeta e opcionalmente apaga as ISOs;
- configura boot somente pelo disco;
- mantém `vga: none`;
- habilita autostart.

## Recuperação

Se precisar recuperar console virtual:

```bash
alexhv recover-display --apply
```

Isso para a VM, remove temporariamente os dispositivos PCI da GPU da
configuração e volta `vga: std`, permitindo usar o console web para diagnóstico.
