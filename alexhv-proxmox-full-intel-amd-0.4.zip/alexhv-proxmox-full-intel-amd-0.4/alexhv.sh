#!/usr/bin/env bash
set -Eeuo pipefail

SELF="$(readlink -f "$0")"
ROOT="$(cd -- "$(dirname -- "$SELF")" && pwd)"
source "$ROOT/config/alexhv.conf"

usage(){
cat <<'EOF'
AlexHV Full v0.4

Uso:
  alexhv inspect
  alexhv full --apply
  alexhv resume --apply
  alexhv finalize [--apply]
  alexhv status
  alexhv recover-display [--apply]
EOF
}

run_bootstrap(){
  local mode="${1:-}"
  [[ "$mode" == "--apply" ]] || {
    echo "Bootstrap completo e destrutivo para instalacao limpa."
    echo "Use: alexhv full --apply"
    exit 1
  }

  systemctl disable alexhv-resume.service >/dev/null 2>&1 || true

  "$ROOT/scripts/00-preflight.sh"
  "$ROOT/scripts/01-storage-consolidate.sh" --apply

  set +e
  "$ROOT/scripts/02-enable-intel-iommu.sh" --apply
  rc=$?
  set -e

  if [[ $rc -eq 10 ]]; then
    echo "[..] Configurando retomada automatica apos reboot..."
    systemctl enable alexhv-resume.service
    echo "[..] Reiniciando Proxmox em 5 segundos..."
    sleep 5
    reboot
    exit 0
  elif [[ $rc -ne 0 ]]; then
    exit "$rc"
  fi

  set +e
  "$ROOT/scripts/03-ensure-isos.sh"
  rc=$?
  set -e
  if [[ $rc -eq 20 ]]; then
    echo
    echo "Depois de colocar Win11.iso no storage local:"
    echo "  alexhv resume --apply"
    exit 20
  elif [[ $rc -ne 0 ]]; then
    exit "$rc"
  fi

  if ! qm status "$VMID" >/dev/null 2>&1; then
    "$ROOT/scripts/04-create-win11-vm.sh" --apply
  fi

  "$ROOT/scripts/05-attach-hardware.sh" --apply
  "$ROOT/scripts/06-start-installer.sh" --apply
}

cmd="${1:-}"
shift || true

case "$cmd" in
  inspect)
    "$ROOT/scripts/00-preflight.sh"
    "$ROOT/scripts/01-storage-consolidate.sh"
    "$ROOT/scripts/02-enable-intel-iommu.sh"
    ;;
  full|resume)
    run_bootstrap "${1:-}"
    ;;
  finalize)
    "$ROOT/scripts/08-finalize.sh" "$@"
    ;;
  status)
    "$ROOT/scripts/09-status.sh"
    ;;
  recover-display)
    "$ROOT/scripts/90-recover-display.sh" "$@"
    ;;
  *)
    usage
    ;;
esac
