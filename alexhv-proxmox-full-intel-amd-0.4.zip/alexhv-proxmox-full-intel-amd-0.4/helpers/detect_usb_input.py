#!/usr/bin/env python3
import os
import subprocess
from pathlib import Path

def props(path):
    try:
        out = subprocess.check_output(
            ["udevadm", "info", "-q", "property", "-p", str(path)],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return {}
    data = {}
    for line in out.splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            data[k] = v
    return data

def usb_ancestor(path):
    p = Path(os.path.realpath(path))
    for candidate in [p] + list(p.parents):
        if (candidate / "idVendor").exists() and (candidate / "idProduct").exists():
            try:
                vid = (candidate / "idVendor").read_text().strip()
                pid = (candidate / "idProduct").read_text().strip()
                product = (candidate / "product").read_text(errors="ignore").strip() if (candidate / "product").exists() else ""
                return vid, pid, candidate.name, product
            except Exception:
                return None
    return None

found = {}
for event in sorted(Path("/sys/class/input").glob("event*")):
    pr = props(event)
    if pr.get("ID_BUS") != "usb":
        continue
    kinds = []
    if pr.get("ID_INPUT_KEYBOARD") == "1":
        kinds.append("keyboard")
    if pr.get("ID_INPUT_MOUSE") == "1":
        kinds.append("mouse")
    if not kinds:
        continue
    anc = usb_ancestor(event / "device")
    if not anc:
        continue
    vid, pid, sysname, product = anc
    key = f"{vid}:{pid}"
    found.setdefault(key, {"kinds": set(), "sysname": sysname, "product": product})
    found[key]["kinds"].update(kinds)

for usb_id, data in found.items():
    print(f"{usb_id}|{','.join(sorted(data['kinds']))}|{data['sysname']}|{data['product']}")
