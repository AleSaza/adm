#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

for c in pveversion qm pvesm lspci lscpu curl python3 qemu-img; do require_cmd "$c"; done

echo "=== AlexHV Full 0.4 / Preflight ==="
echo "Proxmox: $(pveversion | head -1)"
echo "Kernel:  $(uname -r)"
echo "CPU vendor: $(cpu_vendor)"
echo "CPU: $(lscpu | awk -F: '/Model name/{gsub(/^[ \t]+/,"",$2); print $2; exit}')"
echo "Threads: $(nproc)"
echo "RAM: $(free -h | awk '/^Mem:/{print $2}')"
echo

is_intel_cpu || die "Esta versao suporta apenas CPU Intel."
grep -qw vmx /proc/cpuinfo || die "VT-x/VMX nao detectado. Ative virtualizacao na BIOS."

gpu="$(select_gpu)"
echo "[GPU AMD]"
lspci -Dnnk -s "$gpu"
for fn in $(slot_functions "$gpu"); do
  echo "  $fn -> IOMMU $(iommu_group_for_bdf "$fn" 2>/dev/null || echo NONE)"
done

echo
echo "[Storage]"
pvesm status

echo
echo "[IOMMU]"
if iommu_active; then ok "IOMMU ja esta ativo."; else warn "IOMMU ainda nao esta ativo."; fi

echo
echo "[USB input detectado]"
python3 "$BASE_DIR/helpers/detect_usb_input.py" || true
