#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

APPLY=0
has_arg --apply "$@" && APPLY=1

echo "=== AlexHV / Consolidacao de storage ==="
echo "Objetivo: usar /var/lib/vz (storage local) tambem para imagens de VM."
echo

if storage_exists local-lvm; then
  echo "local-lvm existe."
  vols="$(pvesm list local-lvm 2>/dev/null | awk 'NR>1{print $1}')"
  if [[ -n "$vols" ]]; then
    echo "$vols"
    die "local-lvm possui volumes. Por seguranca, nao sera removido."
  fi

  if qm list 2>/dev/null | awk 'NR>1{print $1}' | grep -q .; then
    warn "Existem VMs registradas. Verificando referencias a local-lvm..."
    if grep -Rqs 'local-lvm:' /etc/pve/qemu-server 2>/dev/null; then
      die "Alguma VM referencia local-lvm."
    fi
  fi
  if pct list 2>/dev/null | awk 'NR>1{print $1}' | grep -q .; then
    if grep -Rqs 'local-lvm:' /etc/pve/lxc 2>/dev/null; then
      die "Algum container referencia local-lvm."
    fi
  fi

  echo "Plano:"
  echo "  pvesm remove local-lvm"
  echo "  lvremove /dev/pve/data"
  echo "  lvextend -l +100%FREE /dev/pve/root"
  echo "  expandir filesystem root"
else
  ok "local-lvm ja nao existe."
fi

echo
echo "Storage local sera habilitado para:"
echo "images,iso,vztmpl,backup,rootdir,snippets,import"
echo

if ((!APPLY)); then
  info "Dry-run. Use --apply."
  exit 0
fi

if storage_exists local-lvm; then
  pvesm remove local-lvm
  [[ -e /dev/pve/data ]] && lvremove -y /dev/pve/data
  lvextend -l +100%FREE /dev/pve/root

  fstype="$(findmnt -n -o FSTYPE /)"
  case "$fstype" in
    ext4) resize2fs /dev/mapper/pve-root ;;
    xfs) xfs_growfs / ;;
    *) die "Filesystem root nao suportado para crescimento automatico: $fstype" ;;
  esac
fi

if ! pvesm set local --content images,iso,vztmpl,backup,rootdir,snippets,import; then
  warn "Este Proxmox nao aceitou 'import' via CLI; aplicando os demais tipos."
  pvesm set local --content images,iso,vztmpl,backup,rootdir,snippets
fi

ok "Storage consolidado."
df -h /var/lib/vz
