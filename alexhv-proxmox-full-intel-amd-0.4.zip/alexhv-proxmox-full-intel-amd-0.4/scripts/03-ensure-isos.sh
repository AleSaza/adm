#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

mkdir -p /var/lib/vz/template/iso

echo "=== ISOs ==="

if ! iso_volume_exists "$ISO_STORAGE" "$VIRTIO_ISO"; then
  info "Baixando VirtIO ISO..."
  curl -L --fail --retry 3 --progress-bar "$VIRTIO_ISO_URL" \
    -o "/var/lib/vz/template/iso/$VIRTIO_ISO"
fi
iso_volume_exists "$ISO_STORAGE" "$VIRTIO_ISO" || die "VirtIO ISO nao registrada no storage."

if iso_volume_exists "$ISO_STORAGE" "$WINDOWS_ISO"; then
  ok "Windows ISO encontrada: ${ISO_STORAGE}:iso/${WINDOWS_ISO}"
  exit 0
fi

if [[ -n "${WINDOWS_ISO_URL:-}" ]]; then
  case "$WINDOWS_ISO_URL" in
    https://*.microsoft.com/*|https://*.microsoft.com/*\?*|https://software.download.prss.microsoft.com/*)
      info "Baixando Windows ISO a partir de link Microsoft informado..."
      curl -L --fail --retry 3 --progress-bar "$WINDOWS_ISO_URL" \
        -o "/var/lib/vz/template/iso/$WINDOWS_ISO"
      ;;
    *)
      die "WINDOWS_ISO_URL nao parece ser um link oficial Microsoft."
      ;;
  esac
fi

if ! iso_volume_exists "$ISO_STORAGE" "$WINDOWS_ISO"; then
  set_state "WAITING_FOR_WINDOWS_ISO"
  cat <<EOF
[PAUSA] Win11.iso ainda nao existe.

Baixe a ISO x64 oficial do Windows 11 em Portugues (Brasil) pela pagina da Microsoft:
https://www.microsoft.com/pt-br/software-download/windows11

Depois envie/coloque o arquivo como:
  /var/lib/vz/template/iso/$WINDOWS_ISO

e execute:
  alexhv resume --apply
EOF
  exit 20
fi

ok "Windows ISO pronta."
