#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0
has_arg --apply "$@" && APPLY=1

vm_exists && die "VMID $VMID ja existe."

total_gib="$(root_fs_total_gib)"
avail_gib="$(root_fs_avail_gib)"
used_gib=$(( total_gib - avail_gib ))
reserve_gib="$(host_reserve_gib "$total_gib")"

# A reserva percentual e o ORCAMENTO TOTAL do host, incluindo o proprio Proxmox.
# Se o host ja usa quase todo esse orcamento, preservamos pelo menos 4 GiB de folga.
effective_host_gib="$reserve_gib"
if (( used_gib + 4 > effective_host_gib )); then
  effective_host_gib=$(( used_gib + 4 ))
fi

disk_gib=$(( total_gib - effective_host_gib ))
(( disk_gib < DISK_MIN_GIB )) && die "Espaco insuficiente: alvo calculado ${disk_gib} GiB."

threads="$(nproc)"
cpu_reserve=$(( (threads * (100-CPU_PERCENT) + 99) / 100 ))
(( cpu_reserve < CPU_MIN_HOST_THREADS )) && cpu_reserve="$CPU_MIN_HOST_THREADS"
guest_cpu=$(( threads - cpu_reserve ))

total_mib="$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)"
guest_ram=$(( total_mib * RAM_PERCENT / 100 ))
host_ram=$(( total_mib - guest_ram ))
(( host_ram < RAM_MIN_HOST_MIB )) && guest_ram=$(( total_mib - RAM_MIN_HOST_MIB ))

echo "=== Plano VM Windows 11 ==="
echo "Filesystem local total: ${total_gib} GiB"
echo "Filesystem usado agora: ${used_gib} GiB"
echo "Filesystem livre agora: ${avail_gib} GiB"
echo "Orcamento do host pela politica: ${reserve_gib} GiB"
echo "Orcamento efetivo do host: ${effective_host_gib} GiB"
echo "Disco Windows: ${disk_gib} GiB"
echo "CPU guest: $guest_cpu / $threads"
echo "RAM guest: $guest_ram / $total_mib MiB"
echo "GPU sera anexada antes do primeiro boot."
echo "Display virtual: none"
echo

if ((!APPLY)); then info "Dry-run. Use --apply."; exit 0; fi

qm create "$VMID" \
  --name "$VM_NAME" \
  --ostype win11 \
  --machine q35 \
  --bios ovmf \
  --cpu host \
  --cores "$guest_cpu" \
  --memory "$guest_ram" \
  --balloon 0 \
  --scsihw virtio-scsi-single \
  --net0 "virtio,bridge=$BRIDGE" \
  --agent enabled=1 \
  --tablet 1 \
  --vga none

qm set "$VMID" --efidisk0 "${VM_STORAGE}:1,efitype=4m,pre-enrolled-keys=1"
qm set "$VMID" --tpmstate0 "${VM_STORAGE}:1,version=v2.0"
qm set "$VMID" --scsi0 "${VM_STORAGE}:${disk_gib},format=qcow2,iothread=1,ssd=1,discard=on"
qm set "$VMID" --ide2 "${ISO_STORAGE}:iso/${WINDOWS_ISO},media=cdrom"
qm set "$VMID" --sata1 "${ISO_STORAGE}:iso/${VIRTIO_ISO},media=cdrom"
qm set "$VMID" --boot "order=ide2;scsi0"

set_state "VM_CREATED"
ok "VM criada."
