#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0
has_arg --apply "$@" && APPLY=1

vm_exists || die "VM $VMID nao existe."
vm_running && die "Desligue a VM antes de anexar hardware."
iommu_active || die "IOMMU nao esta ativo."

gpu="$(select_gpu)"
mapfile -t gpu_funcs < <(slot_functions "$gpu")

echo "=== Hardware que ira para a VM ==="
echo "[GPU AMD]"
idx=0
for fn in "${gpu_funcs[@]}"; do
  grp="$(iommu_group_for_bdf "$fn" 2>/dev/null || true)"
  [[ -n "$grp" ]] || die "$fn sem grupo IOMMU."
  echo "  $fn | IOMMU $grp"
  lspci -Dnnk -s "$fn"
  ((idx+=1))
done

echo
echo "[Audio onboard]"
audio_ok=0
if [[ "${ATTACH_ONBOARD_AUDIO:-0}" == "1" && -n "${ONBOARD_AUDIO_BDF:-}" ]] &&
   lspci -s "$ONBOARD_AUDIO_BDF" >/dev/null 2>&1; then
  agrp="$(iommu_group_for_bdf "$ONBOARD_AUDIO_BDF" 2>/dev/null || true)"
  if [[ -n "$agrp" ]]; then
    acount="$(group_members "$agrp" | wc -l)"
    echo "  $ONBOARD_AUDIO_BDF | IOMMU $agrp | membros=$acount"
    lspci -Dnnk -s "$ONBOARD_AUDIO_BDF"
    if (( acount == 1 )); then audio_ok=1; else warn "Audio onboard nao esta isolado; sera ignorado."; fi
  fi
fi

echo
echo "[Mouse/teclado USB]"
mapfile -t detected_inputs < <(
  if [[ -n "${INPUT_USB_IDS:-}" ]]; then
    for id in $INPUT_USB_IDS; do echo "$id|manual|||"; done
  elif [[ "${AUTO_ATTACH_USB_INPUT:-1}" == "1" ]]; then
    python3 "$BASE_DIR/helpers/detect_usb_input.py"
  fi
)

if ((${#detected_inputs[@]} == 0)); then
  warn "Nenhum mouse/teclado USB detectado automaticamente."
  warn "Se necessario, configure INPUT_USB_IDS em $CONF."
else
  printf '  %s\n' "${detected_inputs[@]}"
fi

if ((!APPLY)); then
  info "Dry-run. Use --apply."
  exit 0
fi

idx=0
for fn in "${gpu_funcs[@]}"; do
  opt="${fn},pcie=1"
  [[ "$fn" == "$gpu" ]] && opt="${opt},x-vga=1"
  qm set "$VMID" --"hostpci${idx}" "$opt"
  ((idx+=1))
done

if (( audio_ok == 1 )); then
  hidx="$(next_hostpci_index "$VMID")"
  qm set "$VMID" --"hostpci${hidx}" "${ONBOARD_AUDIO_BDF},pcie=1"
fi

declare -A seen_usb=()
for line in "${detected_inputs[@]}"; do
  usb_id="${line%%|*}"
  [[ "$usb_id" =~ ^[0-9a-fA-F]{4}:[0-9a-fA-F]{4}$ ]] || continue
  [[ -n "${seen_usb[$usb_id]:-}" ]] && continue
  seen_usb[$usb_id]=1
  uidx="$(next_usb_index "$VMID")"
  qm set "$VMID" --"usb${uidx}" "host=${usb_id}"
done

qm set "$VMID" --vga none
set_state "HARDWARE_ATTACHED"
ok "GPU/entrada configurados para instalacao direta no monitor fisico."
qm config "$VMID" | grep -E '^(hostpci|usb|vga|boot|ide2|sata1|scsi0)'
