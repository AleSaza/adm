#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0
has_arg --apply "$@" && APPLY=1

vm_exists || die "VM $VMID nao existe."
gpu="$(select_gpu)"

echo "=== Inicio do Windows Setup ==="
echo "Monitor deve estar conectado fisicamente na GPU AMD:"
lspci -Dnn -s "$gpu"
echo
echo "Mouse/teclado configurados:"
qm config "$VMID" | grep '^usb' || true
echo

if ((!APPLY)); then
  info "Dry-run. Use --apply para iniciar a VM."
  exit 0
fi

vm_running || qm start "$VMID"
set_state "WINDOWS_SETUP_RUNNING"
ok "VM iniciada. Continue a instalacao no monitor ligado a GPU AMD."
echo "Licenca: informe a chave no Setup ou escolha instalar sem chave e ative depois."
