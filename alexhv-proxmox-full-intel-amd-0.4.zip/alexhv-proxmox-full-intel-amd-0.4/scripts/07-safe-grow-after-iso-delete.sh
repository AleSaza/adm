#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0
has_arg --apply "$@" && APPLY=1

vm_exists || die "VM $VMID nao existe."

line="$(qm config "$VMID" | grep '^scsi0:' | head -1 || true)"
[[ -n "$line" ]] || die "scsi0 nao encontrado."
volid="$(sed -E 's/^scsi0:[[:space:]]*([^,]+).*/\1/' <<<"$line")"
path="$(pvesm path "$volid")"
[[ -f "$path" ]] || die "Arquivo do disco nao encontrado: $path"

read -r virt_bytes actual_bytes < <(
  python3 - "$path" <<'PY'
import json, subprocess, sys
p=sys.argv[1]
d=json.loads(subprocess.check_output(["qemu-img","info","--output=json",p], text=True))
print(d.get("virtual-size",0), d.get("actual-size",0))
PY
)

total_bytes="$(df -B1 --output=size /var/lib/vz | tail -1 | tr -dc '0-9')"
avail_bytes="$(df -B1 --output=avail /var/lib/vz | tail -1 | tr -dc '0-9')"
used_bytes=$(( total_bytes - avail_bytes ))

total_gib=$(( total_bytes / 1073741824 ))
reserve_gib="$(host_reserve_gib "$total_gib")"

# Uso fora do disco da VM = uso total do filesystem - blocos fisicos atuais do qcow2.
nonvm_bytes=$(( used_bytes - actual_bytes ))
(( nonvm_bytes < 0 )) && nonvm_bytes=0
nonvm_gib=$(( (nonvm_bytes + 1073741823) / 1073741824 ))

effective_host_gib="$reserve_gib"
if (( nonvm_gib + 4 > effective_host_gib )); then
  effective_host_gib=$(( nonvm_gib + 4 ))
fi

safe_gib=$(( total_gib - effective_host_gib ))
virt_gib=$(( (virt_bytes + 1073741823) / 1073741824 ))

echo "=== Crescimento seguro do disco ==="
echo "Filesystem total: ${total_gib} GiB"
echo "Uso fora da VM: ${nonvm_gib} GiB"
echo "Orcamento host pela politica: ${reserve_gib} GiB"
echo "Orcamento efetivo do host: ${effective_host_gib} GiB"
echo "Virtual atual: ${virt_gib} GiB"
echo "Alvo seguro: ${safe_gib} GiB"

if (( safe_gib <= virt_gib )); then
  ok "Nao ha crescimento seguro adicional."
  exit 0
fi

delta=$(( safe_gib - virt_gib ))
echo "Crescimento: +${delta} GiB"

if ((!APPLY)); then
  info "Dry-run. Use --apply."
  exit 0
fi

qm resize "$VMID" scsi0 "+${delta}G"
ok "Disco virtual ampliado para aproximadamente ${safe_gib} GiB."
