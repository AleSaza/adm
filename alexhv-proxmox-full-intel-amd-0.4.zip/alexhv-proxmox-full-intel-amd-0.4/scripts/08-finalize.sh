#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0
has_arg --apply "$@" && APPLY=1

vm_exists || die "VM $VMID nao existe."

echo "=== Finalizacao AlexHV ==="
echo "- boot pelo scsi0"
echo "- apagar/ejetar ISOs: ${DELETE_INSTALL_ISOS_AFTER_SETUP:-1}"
echo "- manter vga:none"
echo "- desativar Fast Startup/hibernacao via QEMU Guest Agent quando possivel"
echo "- crescer disco com calculo baseado na ocupacao fisica real do qcow2"
echo "- tentar estender C: via Guest Agent"
echo "- autostart: ${AUTO_START:-1}"
echo

if ((!APPLY)); then
  "$SCRIPT_DIR/07-safe-grow-after-iso-delete.sh" || true
  info "Dry-run. Use --apply."
  exit 0
fi

if vm_running; then
  if qm agent "$VMID" ping >/dev/null 2>&1; then
    info "QEMU Guest Agent respondeu."
    qm guest exec "$VMID" -- powershell.exe -NoProfile -NonInteractive -Command \
      "powercfg.exe /h off" >/dev/null 2>&1 || warn "Nao foi possivel desativar hibernacao automaticamente."
  else
    warn "QEMU Guest Agent nao respondeu. Instale virtio-win-guest-tools.exe."
  fi

  qm shutdown "$VMID" --timeout 120 || qm stop "$VMID"
fi

qm set "$VMID" --boot "order=scsi0"

if qm config "$VMID" | grep -q '^ide2:'; then qm set "$VMID" --delete ide2; fi
if qm config "$VMID" | grep -q '^sata1:'; then qm set "$VMID" --delete sata1; fi

if [[ "${DELETE_INSTALL_ISOS_AFTER_SETUP:-1}" == "1" ]]; then
  for iso in "$WINDOWS_ISO" "$VIRTIO_ISO"; do
    vol="${ISO_STORAGE}:iso/${iso}"
    if iso_volume_exists "$ISO_STORAGE" "$iso"; then
      path="$(pvesm path "$vol" 2>/dev/null || true)"
      [[ -n "$path" && -f "$path" ]] && rm -f -- "$path"
    fi
  done
fi

"$SCRIPT_DIR/07-safe-grow-after-iso-delete.sh" --apply || warn "Crescimento extra do disco foi ignorado."

qm set "$VMID" --vga none

if [[ "${AUTO_START:-1}" == "1" ]]; then
  qm set "$VMID" --onboot 1 --startup "order=1,up=${STARTUP_DELAY:-5}"
fi

qm start "$VMID"
sleep 8

if qm agent "$VMID" ping >/dev/null 2>&1; then
  info "Tentando estender C: ate o SizeMax suportado..."
  qm guest exec "$VMID" -- powershell.exe -NoProfile -NonInteractive -Command \
    '$p=Get-Partition -DriveLetter C; $s=$p|Get-PartitionSupportedSize; if($s.SizeMax -gt $p.Size){Resize-Partition -DriveLetter C -Size $s.SizeMax}' \
    >/dev/null 2>&1 || warn "Windows nao permitiu estender C: automaticamente (ex.: particao Recovery no caminho)."
fi

set_state "FINALIZED"
ok "Finalizacao concluida."
