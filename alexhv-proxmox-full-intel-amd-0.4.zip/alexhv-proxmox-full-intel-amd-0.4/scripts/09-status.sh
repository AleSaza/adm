#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

echo "=== AlexHV Status ==="
echo "State: $(get_state)"
echo "Proxmox: $(pveversion | head -1)"
echo "CPU vendor: $(cpu_vendor)"
echo "IOMMU: $(iommu_active && echo ativo || echo inativo)"
echo
echo "[Storage]"
pvesm status
df -h /var/lib/vz
echo
echo "[GPU AMD]"
if gpu="$(select_gpu 2>/dev/null)"; then
  for fn in $(slot_functions "$gpu"); do
    drv="$(basename "$(readlink -f "/sys/bus/pci/devices/$fn/driver" 2>/dev/null)" 2>/dev/null || true)"
    echo "$fn -> ${drv:-none}"
    lspci -Dnn -s "$fn"
  done
fi
echo
echo "[VM]"
if vm_exists; then
  qm status "$VMID"
  qm config "$VMID"
else
  echo "VM $VMID ainda nao existe."
fi
