#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0
has_arg --apply "$@" && APPLY=1

vm_exists || die "VM $VMID nao existe."

echo "=== Recuperar console virtual ==="
echo "A VM sera desligada e vga: std sera habilitado."
echo "A GPU PCI continuara anexada para facilitar diagnostico."

if ((!APPLY)); then
  info "Dry-run. Use --apply."
  exit 0
fi

if vm_running; then qm shutdown "$VMID" --timeout 60 || qm stop "$VMID"; fi
qm set "$VMID" --vga std
qm start "$VMID"
ok "Console virtual restaurado. Use noVNC para diagnostico."
