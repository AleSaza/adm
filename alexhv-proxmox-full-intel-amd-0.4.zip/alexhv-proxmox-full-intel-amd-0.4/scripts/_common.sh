#!/usr/bin/env bash
set -Eeuo pipefail

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
SCRIPT_DIR="$(cd -- "$(dirname -- "$SELF")" && pwd)"
BASE_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
CONF="${ALEXHV_CONFIG:-$BASE_DIR/config/alexhv.conf}"
STATE_DIR="/var/lib/alexhv"
STATE_FILE="$STATE_DIR/bootstrap.state"
mkdir -p "$STATE_DIR"

[[ -f "$CONF" ]] && source "$CONF"

die(){ echo "[ERRO] $*" >&2; exit 1; }
ok(){ echo "[OK] $*"; }
info(){ echo "[..] $*"; }
warn(){ echo "[AVISO] $*" >&2; }

require_root(){ [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Execute como root."; }
require_cmd(){ command -v "$1" >/dev/null 2>&1 || die "Comando ausente: $1"; }

has_arg(){
  local needle="$1"; shift || true
  for arg in "$@"; do [[ "$arg" == "$needle" ]] && return 0; done
  return 1
}

set_state(){ printf '%s\n' "$1" > "$STATE_FILE"; }
get_state(){ [[ -f "$STATE_FILE" ]] && cat "$STATE_FILE" || echo "NEW"; }

cpu_vendor(){
  lscpu | awk -F: '/Vendor ID/{gsub(/^[ \t]+/,"",$2);print $2;exit}'
}

is_intel_cpu(){ [[ "$(cpu_vendor)" == "GenuineIntel" ]]; }

iommu_active(){
  [[ -d /sys/kernel/iommu_groups ]] &&
  find /sys/kernel/iommu_groups -mindepth 1 -maxdepth 1 -type d 2>/dev/null | grep -q .
}

amd_display_gpus(){
  lspci -Dnn | awk 'BEGIN{IGNORECASE=1}
  /\[1002:/ && ($0 ~ /VGA compatible controller/ || $0 ~ /3D controller/ || $0 ~ /Display controller/) {print $1}'
}

select_gpu(){
  if [[ -n "${GPU_BDF:-}" ]]; then echo "$GPU_BDF"; return; fi
  mapfile -t gpus < <(amd_display_gpus)
  if [[ ${#gpus[@]} -eq 1 ]]; then
    echo "${gpus[0]}"
  elif [[ ${#gpus[@]} -eq 0 ]]; then
    die "Nenhuma GPU AMD de video detectada."
  else
    printf 'GPUs AMD detectadas:\n' >&2
    printf '  %s\n' "${gpus[@]}" >&2
    die "Defina GPU_BDF em $CONF."
  fi
}

slot_functions(){
  local gpu="$1" slot="${1%.*}"
  lspci -Dnn | awk -v slot="$slot" '$1 ~ ("^" slot "\\.") {print $1}'
}

iommu_group_for_bdf(){
  local bdf="$1" link="/sys/bus/pci/devices/$1/iommu_group"
  [[ -L "$link" ]] || return 1
  basename "$(readlink -f "$link")"
}

group_members(){
  local group="$1" dir="/sys/kernel/iommu_groups/$1/devices"
  [[ -d "$dir" ]] || return 0
  for d in "$dir"/*; do [[ -e "$d" ]] && basename "$d"; done
}

storage_exists(){ pvesm status --storage "$1" >/dev/null 2>&1; }

iso_volume_exists(){
  local storage="$1" file="$2"
  pvesm list "$storage" 2>/dev/null | awk '{print $1}' | grep -Fxq "${storage}:iso/${file}"
}

storage_path(){
  pvesm path "$1"
}

root_fs_total_gib(){
  df -BG --output=size /var/lib/vz | tail -1 | tr -dc '0-9'
}

root_fs_avail_gib(){
  df -BG --output=avail /var/lib/vz | tail -1 | tr -dc '0-9'
}

host_reserve_gib(){
  local total="$1" reserve
  if (( total <= 400 )); then
    reserve=$(( (total * 20 + 99) / 100 ))
  elif (( total <= 900 )); then
    reserve=$(( (total * 5 + 99) / 100 ))
  else
    reserve=$(( (total * 25 + 999) / 1000 ))
  fi
  (( reserve < ${HOST_MIN_RESERVE_GIB:-16} )) && reserve="${HOST_MIN_RESERVE_GIB:-16}"
  echo "$reserve"
}

next_hostpci_index(){
  local vmid="$1" i
  for i in $(seq 0 15); do
    if ! qm config "$vmid" 2>/dev/null | grep -q "^hostpci${i}:"; then
      echo "$i"; return 0
    fi
  done
  die "Sem slot hostpci livre."
}

next_usb_index(){
  local vmid="$1" i
  for i in $(seq 0 13); do
    if ! qm config "$vmid" 2>/dev/null | grep -q "^usb${i}:"; then
      echo "$i"; return 0
    fi
  done
  die "Sem slot usb livre."
}

vm_exists(){ qm status "${VMID:-100}" >/dev/null 2>&1; }
vm_running(){ [[ "$(qm status "${VMID:-100}" 2>/dev/null | awk '{print $2}')" == "running" ]]; }
