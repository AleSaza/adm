# AlexHV Full Bootstrap — Intel CPU + AMD GPU — v0.5

Esta versão consolida o fluxo que funcionou no hardware físico e adiciona
download automático da ISO mais recente do Windows 11 x64 em Português (Brasil)
usando o projeto open-source `starkSV/windows-iso-downloader` (MSDL).

## Um comando em Proxmox limpo

```bash
chmod +x install.sh
./install.sh --full
```

Depois de confirmar com `FULL`, o AlexHV:

1. valida CPU Intel, VMX e GPU AMD;
2. consolida `local-lvm` vazio em `pve/root`;
3. habilita o storage `local` para imagens/ISO/backups/etc.;
4. ativa Intel VT-d/IOMMU se necessário;
5. reinicia e retoma automaticamente quando necessário;
6. baixa a ISO VirtIO;
7. instala automaticamente o CLI `msdl` da release mais recente do GitHub;
8. consulta `msdl --list`;
9. escolhe automaticamente o Windows 11 consumer x64 mais recente;
10. solicita ao MSDL o link assinado da Microsoft em Português (Brasil);
11. baixa a ISO diretamente do domínio oficial Microsoft para `Win11.iso`;
12. cria a VM Windows 11;
13. anexa GPU AMD + funções do mesmo slot;
14. anexa áudio onboard Intel isolado, quando habilitado;
15. detecta mouse/teclado USB;
16. usa `vga: none`;
17. inicia o Windows Setup diretamente no monitor da GPU AMD.

## Download do Windows — MSDL

Projeto usado:

- Repositório: https://github.com/starkSV/windows-iso-downloader
- CLI: `msdl`
- Licença do projeto: MIT

O AlexHV não hospeda nem redistribui a ISO do Windows. O MSDL obtém uma URL
assinada e a ISO é baixada diretamente do CDN da Microsoft.

Por padrão também desativamos no MSDL:

```text
MSDL_NO_TELEMETRY=1
MSDL_NO_CONTRIBUTE=1
```

O produto Windows não é hardcoded. O AlexHV lê a saída atual de:

```bash
msdl --list
```

e escolhe o Windows 11 x64 normal mais recente, ignorando ARM64 e edições China.

Idioma desejado:

```text
Portuguese (Brazil)
```

Há fallbacks de nomenclatura apenas para lidar com mudanças no texto devolvido
pela API Microsoft.

Você pode testar/forçar somente a etapa de ISO com:

```bash
alexhv windows-iso
```

## Segurança do download

Antes do download da ISO, o AlexHV verifica se a URL retornada pelo MSDL:

- usa HTTPS; e
- pertence ao domínio `microsoft.com` ou um subdomínio dele.

A ISO é baixada primeiro como `.part`, validada por tamanho mínimo e só depois
renomeada para:

```text
/var/lib/vz/template/iso/Win11.iso
```

Também ficam gravados metadados e SHA-256 em:

```text
/var/lib/alexhv/windows-msdl.meta
/var/lib/alexhv/Win11.iso.sha256
/var/lib/alexhv/msdl.sha256
```

## Licença do Windows

A automação não ativa Windows e não contorna licenciamento.

No Windows Setup, o usuário pode:

- inserir sua chave de produto; ou
- escolher instalar sem chave e ativar posteriormente no próprio Windows.

## Política de disco

Depois de consolidar o storage:

- até 400 GiB úteis: orçamento do host = 20%;
- acima de 400 e até 900 GiB: orçamento do host = 5%;
- acima de 900 GiB: orçamento do host = 2,5%.

O restante seguro vira o disco do Windows.

O cálculo considera o filesystem real do Proxmox e não soma incorretamente
tamanho virtual QCOW2 + espaço livre.

## Instalação no monitor físico

Antes do primeiro boot:

```text
GPU AMD física
+ HDMI Audio
+ mouse/teclado USB
+ áudio onboard opcional
        ↓
Windows VM
        ↓
vga: none
        ↓
monitor físico
        ↓
Windows Setup
```

O noVNC não é necessário no fluxo normal.

Se o Windows Setup não enxergar o disco VirtIO, carregue o driver pelo CD
`virtio-win.iso`.

## Depois de chegar ao desktop

Dentro do Windows:

1. execute `virtio-win-guest-tools.exe`;
2. instale o driver AMD;
3. confirme rede, GPU, teclado e mouse.

Depois no Proxmox:

```bash
alexhv finalize --apply
```

A finalização:

- tenta desativar hibernação/Fast Startup via QEMU Guest Agent;
- ejeta as ISOs;
- apaga as ISOs se configurado;
- recalcula crescimento seguro do disco;
- tenta estender `C:`;
- mantém `vga: none`;
- ativa autostart;
- inicia novamente a VM.

## Recuperação de vídeo

```bash
alexhv recover-display --apply
```

Isso volta temporariamente para `vga: std` para diagnóstico pelo console web.

## Escopo desta versão

Suportado nesta v0.5:

```text
CPU Intel + GPU AMD
```

Perfis AMD CPU e NVIDIA serão tratados em versões posteriores.
