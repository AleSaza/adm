# Fluxo FULL — v0.5

## Proxmox limpo

```bash
unzip alexhv-proxmox-full-intel-amd-0.4.zip
cd alexhv-proxmox-full-intel-amd-0.4
chmod +x install.sh
./install.sh --full
```

O script pede a palavra `FULL` antes de iniciar mudanças.

## Etapas automáticas

1. valida CPU Intel, VMX e GPU AMD;
2. consolida `local-lvm` vazio em `pve/root`;
3. habilita content types no storage `local`;
4. ativa Intel VT-d/IOMMU se necessário;
5. se houver reboot, retoma via systemd;
6. garante VirtIO ISO;
7. instala/atualiza o CLI MSDL do projeto windows-iso-downloader;
8. detecta automaticamente o Windows 11 consumer x64 mais recente suportado;
9. obtém link assinado Microsoft para Português (Brasil) e baixa Win11.iso;
10. cria a VM;
9. calcula recursos;
10. anexa GPU AMD;
11. anexa áudio onboard se isolado;
12. detecta mouse/teclado USB;
13. configura `vga:none`;
14. inicia Windows Setup na GPU física.

## Política de disco

O percentual é o orçamento TOTAL do host, não uma reserva livre adicional.

- filesystem útil <= 400 GiB: host 20%, Windows o restante;
- >400 e <=900 GiB: host 5%, Windows o restante;
- >900 GiB: host 2,5%, Windows o restante.

Se o Proxmox/ISOs já consomem quase todo o orçamento do host, o Windows é
reduzido automaticamente para manter pelo menos 4 GiB de folga.

Na finalização, depois de apagar ISOs, o script recalcula o alvo sem somar
erroneamente o tamanho virtual do QCOW2 ao espaço livre. Ele separa:

- tamanho virtual do disco;
- blocos físicos realmente ocupados pelo QCOW2;
- uso do filesystem fora da VM.

Isso evita o erro anterior que sugeria 134 GiB em um disco físico menor.

## Instalação Windows

A instalação é interativa no monitor físico. O usuário pode inserir uma chave
de produto durante o Setup ou instalar sem chave e ativar depois.

Para disco VirtIO SCSI, carregue o driver da ISO VirtIO se o Windows Setup não
mostrar o disco.

Após chegar ao desktop:

1. execute `virtio-win-guest-tools.exe`;
2. instale o driver AMD;
3. confirme GPU, mouse, teclado e rede;
4. execute:

```bash
alexhv finalize --apply
```

## ISO automática via MSDL

A automação usa `starkSV/windows-iso-downloader` para obter a URL assinada
diretamente do CDN Microsoft. Não há fallback para fontes de ativação/bypass.

O usuário não precisa verificar manualmente se `Win11.iso` existe no bootstrap
normal. O script detecta, baixa e registra a ISO automaticamente.
