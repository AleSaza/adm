# Third-party component notice

## windows-iso-downloader / MSDL

AlexHV v0.5 integra em runtime o CLI `msdl` do projeto:

https://github.com/starkSV/windows-iso-downloader

O projeto declara licença MIT e informa que obtém links oficiais de ISO
diretamente do CDN Microsoft. O AlexHV não incorpora o binário MSDL neste ZIP;
a release mais recente para Linux x86_64 é baixada do GitHub Releases durante
o bootstrap.

O AlexHV desativa telemetria e contribuição de cache do MSDL por padrão.

MSDL não é afiliado, endossado ou patrocinado pela Microsoft. Windows é marca
registrada da Microsoft Corporation.
