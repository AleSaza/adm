#!/usr/bin/env python3
import re
import sys

products = []
for raw in sys.stdin:
    line = raw.rstrip()
    m = re.match(r"^\s*(\d+)\s+(.+?)\s*$", line)
    if not m:
        continue
    pid, name = m.group(1), m.group(2)

    low = name.lower()
    if not low.startswith("windows 11"):
        continue
    if "arm64" in low or "home china" in low or "pro china" in low:
        continue

    # Prefer the newest Windows release family (e.g. 26H1 > 25H2 > 24H2),
    # then a V2/V3 refresh, then the numeric product ID as a stable tiebreaker.
    vh = re.search(r"\b(\d{2})H(\d)\b", name, re.I)
    year = int(vh.group(1)) if vh else 0
    half = int(vh.group(2)) if vh else 0

    vr = re.search(r"\(V(\d+)\)", name, re.I)
    revision = int(vr.group(1)) if vr else 0

    products.append(((year, half, revision, int(pid)), pid, name))

if not products:
    print("No eligible Windows 11 x64 consumer product found.", file=sys.stderr)
    sys.exit(1)

products.sort()
_, pid, name = products[-1]
print(f"{pid}|{name}")
