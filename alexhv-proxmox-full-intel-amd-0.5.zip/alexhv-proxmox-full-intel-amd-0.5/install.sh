#!/usr/bin/env bash
set -Eeuo pipefail

[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Execute como root." >&2; exit 1; }

SELF="$(readlink -f "$0")"
SRC="$(cd -- "$(dirname -- "$SELF")" && pwd)"
DST="/opt/alexhv"
FULL=0

need_pkgs=()
command -v curl >/dev/null 2>&1 || need_pkgs+=(curl)
command -v python3 >/dev/null 2>&1 || need_pkgs+=(python3)
[[ -f /etc/ssl/certs/ca-certificates.crt ]] || need_pkgs+=(ca-certificates)

if ((${#need_pkgs[@]})); then
  echo "[..] Instalando dependencias: ${need_pkgs[*]}"
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y "${need_pkgs[@]}"
fi

for arg in "$@"; do
  [[ "$arg" == "--full" ]] && FULL=1
done

mkdir -p "$DST"
cp -a "$SRC"/. "$DST"/
chmod +x "$DST/alexhv.sh" "$DST/install.sh" "$DST/scripts"/*.sh "$DST/helpers"/*.py
ln -sfn "$DST/alexhv.sh" /usr/local/sbin/alexhv

cat > /etc/systemd/system/alexhv-resume.service <<'EOF'
[Unit]
Description=Resume AlexHV bootstrap after IOMMU reboot
After=network-online.target pve-cluster.service
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/opt/alexhv/alexhv.sh resume --apply
RemainAfterExit=no

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload

echo "[OK] AlexHV Full v0.5 instalado em $DST"
echo "[OK] Comando: alexhv"

if (( FULL == 1 )); then
  echo
  echo "ATENCAO: --full e destinado a Proxmox limpo."
  echo "Ele pode remover local-lvm VAZIO, expandir pve/root, configurar IOMMU,"
  echo "criar a VM e entregar GPU/input ao Windows."
  echo
  read -r -p "Digite FULL para continuar: " answer
  [[ "$answer" == "FULL" ]] || { echo "Cancelado."; exit 1; }
  exec /usr/local/sbin/alexhv full --apply
else
  echo "Proximo passo: alexhv inspect"
  echo "Para bootstrap completo em Proxmox limpo: ./install.sh --full"
fi
