#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

mkdir -p /var/lib/vz/template/iso

echo "=== ISOs ==="

if ! iso_volume_exists "$ISO_STORAGE" "$VIRTIO_ISO"; then
  info "Baixando VirtIO ISO oficial..."
  curl -L --fail --retry 5 --retry-delay 3 --connect-timeout 30 \
    --progress-bar "$VIRTIO_ISO_URL" \
    -o "/var/lib/vz/template/iso/$VIRTIO_ISO"
fi
iso_volume_exists "$ISO_STORAGE" "$VIRTIO_ISO" || die "VirtIO ISO nao registrada no storage."

if [[ "${WINDOWS_AUTO_DOWNLOAD:-1}" == "1" ]]; then
  "$SCRIPT_DIR/03a-download-windows-msdl.sh"
else
  iso_volume_exists "$ISO_STORAGE" "$WINDOWS_ISO" ||
    die "WINDOWS_AUTO_DOWNLOAD=0 e ${ISO_STORAGE}:iso/${WINDOWS_ISO} nao existe."
fi

iso_volume_exists "$ISO_STORAGE" "$WINDOWS_ISO" ||
  die "Windows ISO nao foi registrada no storage apos o download."

ok "ISOs prontas:"
echo "  ${ISO_STORAGE}:iso/${WINDOWS_ISO}"
echo "  ${ISO_STORAGE}:iso/${VIRTIO_ISO}"
