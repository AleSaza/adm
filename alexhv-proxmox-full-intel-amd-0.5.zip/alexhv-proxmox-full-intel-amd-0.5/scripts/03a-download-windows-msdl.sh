#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

MSDL_BIN="/usr/local/bin/msdl"
MSDL_META="$STATE_DIR/windows-msdl.meta"
MSDL_LIST="$STATE_DIR/msdl-products.txt"
ISO_PATH="/var/lib/vz/template/iso/$WINDOWS_ISO"
ISO_PART="${ISO_PATH}.part"

install_msdl(){
  if [[ -x "$MSDL_BIN" ]]; then
    return 0
  fi

  info "Instalando MSDL (starkSV/windows-iso-downloader) a partir do GitHub Releases..."
  tmp="$(mktemp)"
  curl -L --fail --retry 5 --connect-timeout 20 --progress-bar \
    "$MSDL_BINARY_URL" -o "$tmp"
  install -m 0755 "$tmp" "$MSDL_BIN"
  rm -f "$tmp"

  "$MSDL_BIN" --help >/dev/null 2>&1 || die "MSDL foi baixado, mas nao executou."
  sha256sum "$MSDL_BIN" | tee "$STATE_DIR/msdl.sha256" >/dev/null
  ok "MSDL instalado: $("$MSDL_BIN" --help 2>&1 | head -1 || true)"
}

latest_product(){
  MSDL_NO_TELEMETRY=1 MSDL_NO_CONTRIBUTE=1 \
    "$MSDL_BIN" --list >"$MSDL_LIST.stdout" 2>"$MSDL_LIST"

  # --list escreve a lista em stderr; mantenha stdout junto por compatibilidade futura.
  cat "$MSDL_LIST.stdout" >> "$MSDL_LIST" || true
  rm -f "$MSDL_LIST.stdout"

  python3 "$BASE_DIR/helpers/select_latest_msdl_product.py" < "$MSDL_LIST"
}

fetch_signed_url(){
  local pid="$1"
  local -a langs=(
    "${WINDOWS_LANGUAGE:-Portuguese (Brazil)}"
    "Portuguese (Brazil)"
    "Portuguese - Brazil"
    "Portuguese-Brazil"
    "Portuguese"
  )

  local lang out errfile
  errfile="$(mktemp)"
  for lang in "${langs[@]}"; do
    : > "$errfile"
    if out="$(
      MSDL_NO_TELEMETRY=1 MSDL_NO_CONTRIBUTE=1 \
      "$MSDL_BIN" --id "$pid" --lang "$lang" --no-contribute 2>"$errfile"
    )"; then
      url="$(printf '%s\n' "$out" | grep -E '^https://' | head -1 || true)"
      if [[ -n "$url" ]]; then
        printf '%s|%s\n' "$url" "$lang"
        rm -f "$errfile"
        return 0
      fi
    fi
  done

  echo "MSDL nao conseguiu obter pt-BR. Ultimo retorno:" >&2
  cat "$errfile" >&2 || true
  rm -f "$errfile"
  return 1
}

validate_ms_url(){
  python3 - "$1" <<'PY'
import sys
from urllib.parse import urlparse

u = urlparse(sys.argv[1])
host = (u.hostname or "").lower()
ok = (
    u.scheme == "https"
    and (
        host == "microsoft.com"
        or host.endswith(".microsoft.com")
    )
)
sys.exit(0 if ok else 1)
PY
}

mkdir -p /var/lib/vz/template/iso "$STATE_DIR"

install_msdl

product="$(latest_product)"
pid="${product%%|*}"
pname="${product#*|}"

echo "=== Windows ISO automatico via MSDL ==="
echo "Projeto: starkSV/windows-iso-downloader"
echo "Produto mais recente x64 selecionado: $pname"
echo "Product ID: $pid"
echo "Idioma desejado: ${WINDOWS_LANGUAGE:-Portuguese (Brazil)}"

current_id=""
current_name=""
if [[ -f "$MSDL_META" ]]; then
  current_id="$(awk -F= '$1=="product_id"{print substr($0,index($0,"=")+1)}' "$MSDL_META" | tail -1)"
  current_name="$(awk -F= '$1=="product_name"{print substr($0,index($0,"=")+1)}' "$MSDL_META" | tail -1)"
fi

if [[ -f "$ISO_PATH" && "$current_id" == "$pid" && "$current_name" == "$pname" ]]; then
  ok "Win11.iso ja corresponde ao produto mais recente conhecido pelo MSDL."
  exit 0
fi

if [[ -f "$ISO_PATH" && -z "$current_id" && "${WINDOWS_ISO_REFRESH_IF_UNKNOWN:-1}" != "1" ]]; then
  ok "Win11.iso ja existe; refresh desconhecido desabilitado."
  exit 0
fi

result="$(fetch_signed_url "$pid")" || die "Falha ao obter URL assinada da Microsoft via MSDL."
url="${result%%|*}"
lang="${result#*|}"

validate_ms_url "$url" || die "MSDL retornou URL fora do dominio microsoft.com; download abortado."

info "URL oficial Microsoft obtida. Baixando Windows 11 ($lang)..."
rm -f "$ISO_PART"
curl -L --fail --retry 5 --retry-delay 3 --connect-timeout 30 \
  --progress-bar "$url" -o "$ISO_PART"

size="$(stat -c '%s' "$ISO_PART")"
(( size > 3 * 1024 * 1024 * 1024 )) || die "ISO baixada parece pequena demais (${size} bytes)."

mv -f "$ISO_PART" "$ISO_PATH"

cat > "$MSDL_META" <<EOF
product_id=$pid
product_name=$pname
language=$lang
source_project=starkSV/windows-iso-downloader
source_repo=https://github.com/starkSV/windows-iso-downloader
download_host=$(python3 - "$url" <<'PY'
import sys
from urllib.parse import urlparse
print(urlparse(sys.argv[1]).hostname or "")
PY
)
downloaded_at=$(date -Is)
EOF

sha256sum "$ISO_PATH" | tee "$STATE_DIR/Win11.iso.sha256" >/dev/null
ok "Windows ISO baixada automaticamente: $ISO_PATH"
