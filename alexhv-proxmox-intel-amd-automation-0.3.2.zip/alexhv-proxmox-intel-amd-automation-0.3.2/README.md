# AlexHV Proxmox — Automação Intel CPU + AMD GPU — v0.3.2

Consolida o fluxo validado no Proxmox físico.

## Automatiza

- VT-x / VT-d / IOMMU Intel;
- detecção das ISOs Win11 e VirtIO;
- VM Windows 11 Q35 + OVMF/UEFI + TPM 2.0 + VirtIO;
- ~90% CPU/RAM, preservando recursos para o host;
- um disco virtual grande no local-lvm já no tamanho final seguro;
- GPU AMD e funções PCI relacionadas;
- áudio onboard Intel opcional;
- mouse/teclado USB detectados automaticamente por HID;
- autostart;
- finalização sem display virtual (`vga: none`), portanto sem noVNC;
- crescimento do disco virtual até o máximo seguro do `local-lvm` (quando esta for a única VM);
- tentativa segura de expandir C: via QEMU Guest Agent;
- desabilitação de Fast Startup/hibernação do Windows.

## Sobre local e local-lvm

A automação **não funde** `local` e `local-lvm`. O `local` continua para ISO/backup e o `local-lvm` para o disco da VM. Isso evita uma alteração destrutiva do host. Para o Windows há um único disco virtual principal. UEFI/Windows 11 ainda cria pequenas partições ocultas EFI/MSR/Recovery; o volume visível principal é `C:`.

## Fluxo

```bash
./alexhv.sh inspect
./alexhv.sh prepare
./alexhv.sh prepare --apply
```

Instale o Windows e `virtio-win-guest-tools.exe`. Depois, com a VM desligada:

```bash
./alexhv.sh hardware
./alexhv.sh hardware --apply
```

Valide a GPU AMD no monitor físico e instale o driver AMD. Depois, com a VM ligada e o QEMU Guest Agent funcionando:

```bash
./alexhv.sh finalize
./alexhv.sh finalize --apply
```

A finalização remove o display virtual/noVNC, deixa boot em `scsi0`, ejeta as ISOs, ativa autostart e reinicia a VM.

Para recuperar o console virtual:

```bash
./scripts/90-restore-virtual-display.sh --apply
```

Esta versão é específica para **CPU Intel + GPU AMD**.

## Observação para VM já instalada

Em instalações novas o disco já nasce no tamanho final antes do Windows Setup, então o C: aproveita praticamente todo o espaço desde o começo. Em uma VM já instalada, `finalize` pode aumentar o `scsi0` e depois tenta expandir o C:. Se uma partição Recovery estiver fisicamente depois do C:, o Windows pode impedir a expansão; a automação **não apaga nem move essa partição automaticamente**, pois isso seria destrutivo.


## Correção 0.3.1
O comando global `alexhv` agora resolve corretamente o link simbólico em `/usr/local/sbin`.


## Storage single-local (novo na 0.3.2)

Em instalação limpa, `alexhv prepare --apply` pode consolidar o layout padrão do Proxmox:

- remove `local-lvm` / `pve/data` **somente se estiver vazio e não referenciado por VM/CT**;
- expande `pve/root` com `+100%FREE`;
- expande o filesystem raiz (`ext4` ou `xfs`);
- usa `/var/lib/vz` como storage único `local`;
- habilita `Disk image`, `ISO image`, `Container template`, `Backup`, `Container`, `Snippets` e `Import`;
- define `qcow2` como formato padrão para imagens de VM em `local`.

Esse fluxo reproduz a consolidação manual validada no host. O script se recusa a apagar `pve/data` se houver volumes ou referências a `local-lvm`.

Dry-run isolado:

```bash
alexhv storage
```

Aplicar numa instalação limpa:

```bash
alexhv storage --apply
```
