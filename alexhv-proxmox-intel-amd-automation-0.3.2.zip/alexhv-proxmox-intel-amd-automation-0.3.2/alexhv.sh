#!/usr/bin/env bash
set -Eeuo pipefail
SELF="$(readlink -f "$0")"
ROOT="$(cd -- "$(dirname -- "$SELF")" && pwd)"
cmd="${1:-help}"; shift || true
case "$cmd" in
  inspect)
    "$ROOT/scripts/00-preflight.sh" "$@"
    "$ROOT/scripts/01a-consolidate-storage.sh" "$@"
    "$ROOT/scripts/01-plan.sh" "$@"
    ;;
  storage)
    "$ROOT/scripts/01a-consolidate-storage.sh" "$@"
    ;;
  prepare)
    "$ROOT/scripts/01a-consolidate-storage.sh" "$@"
    "$ROOT/scripts/02-ensure-intel-iommu.sh" "$@"
    "$ROOT/scripts/03-check-isos.sh" "$@"
    "$ROOT/scripts/04-create-or-validate-vm.sh" "$@"
    ;;
  hardware)
    "$ROOT/scripts/05-attach-amd-gpu.sh" "$@"
    "$ROOT/scripts/06-attach-onboard-audio.sh" "$@"
    "$ROOT/scripts/07-attach-usb-input.sh" "$@"
    ;;
  finalize)
    "$ROOT/scripts/08a-grow-disk-to-safe-max.sh" "$@"
    "$ROOT/scripts/08-finalize-windows.sh" "$@"
    ;;
  status)
    "$ROOT/scripts/10-status.sh" "$@"
    ;;
  help|*)
    cat <<EOF
AlexHV v0.3.2

Uso:
  ./alexhv.sh inspect
  ./alexhv.sh storage [--apply]
  ./alexhv.sh prepare [--apply]
  ./alexhv.sh hardware [--apply]
  ./alexhv.sh finalize [--apply]
  ./alexhv.sh status
EOF
    ;;
esac
