# Correção 0.3.1

A versão 0.3 criava o link:

`/usr/local/sbin/alexhv -> /opt/alexhv/alexhv.sh`

mas o launcher calculava o diretório-base a partir de `$0`. Quando chamado pelo
link simbólico, ele assumia incorretamente `/usr/local/sbin` como base e tentava
abrir `/usr/local/sbin/scripts/...`.

A versão 0.3.1 resolve o caminho real do launcher com `readlink -f` antes de
calcular o diretório-base.

Nenhuma configuração da VM ou do Proxmox é alterada por esta correção.
