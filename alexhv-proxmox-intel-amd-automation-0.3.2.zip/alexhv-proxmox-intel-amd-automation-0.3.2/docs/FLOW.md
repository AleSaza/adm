# Fluxo operacional da automação

## Instalação da automação no Proxmox

```bash
unzip alexhv-proxmox-intel-amd-automation-0.3.2.zip
cd alexhv-proxmox-intel-amd-automation-0.3
./install.sh
```

Depois use o comando global `alexhv`.

## Fase 1 — host e VM

```bash
alexhv inspect
alexhv prepare
alexhv prepare --apply
```

Se o IOMMU já estiver ativo, nenhuma alteração de boot é feita. Se não estiver, a automação configura `intel_iommu=on iommu=pt` e informa que é necessário reiniciar.

A VM nasce com display virtual para permitir instalação pelo noVNC. O disco é criado no tamanho final seguro antes do Windows Setup, evitando precisar redimensionar depois.

## Fase 2 — Windows

Instale o Windows 11. Quando o instalador não enxergar o disco VirtIO, carregue o driver `vioscsi\w11\amd64` da ISO VirtIO. No desktop execute `virtio-win-guest-tools.exe`.

## Fase 3 — hardware físico

Desligue a VM:

```bash
alexhv hardware
alexhv hardware --apply
```

A automação:

1. detecta a única GPU AMD e passa todas as funções do mesmo slot PCI;
2. passa o áudio onboard somente se o grupo IOMMU estiver isolado;
3. procura eventos USB HID de teclado/mouse;
4. converte esses eventos em portas USB físicas estáveis e adiciona `usbN` à VM.

Mantenha o display virtual nesse momento. Inicie o Windows, instale o driver AMD e confirme vídeo no monitor ligado diretamente à GPU.

## Fase 4 — workstation final

```bash
alexhv finalize
alexhv finalize --apply
```

A finalização usa o QEMU Guest Agent para desabilitar Fast Startup e tentar expandir C:, desliga o Windows, ejeta as ISOs, deixa boot em `scsi0`, configura `vga: none`, autostart e liga a VM novamente.

A partir daqui o uso normal é:

```text
Power -> Proxmox -> autostart VM -> GPU AMD -> Windows 11
```

## Recuperação

Voltar noVNC:

```bash
/opt/alexhv/scripts/90-restore-virtual-display.sh --apply
```

Remover mouse/teclado USB da VM:

```bash
/opt/alexhv/scripts/91-detach-usb-input.sh --apply
```

## Storage

`local` e `local-lvm` continuam separados. A automação não modifica a estrutura LVM do Proxmox. Isso é deliberado. `local` guarda ISOs/backups e `local-lvm` guarda o disco da VM. Windows recebe um único disco virtual principal com o máximo seguro do thin-pool, preservando a reserva definida em `DISK_RESERVE_GIB`.
