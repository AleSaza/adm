# Storage single-local — 0.3.2

Esta etapa automatiza o procedimento validado manualmente:

```bash
lvremove /dev/pve/data
lvresize -l +100%FREE /dev/pve/root
resize2fs /dev/mapper/pve-root
```

A automação é mais segura que os comandos manuais: ela verifica referências e volumes de `local-lvm` antes de permitir a remoção.

Depois configura o storage `local` (`/var/lib/vz`) para aceitar:

- images — Disk image
- iso — ISO image
- vztmpl — Container template
- backup — Backup
- rootdir — Container
- snippets — Snippets
- import — Import

Também define `qcow2` como formato padrão de imagens no storage Directory, preservando a possibilidade de snapshots de VM via qcow2.
