$ErrorActionPreference = "Stop"

Write-Host "AlexHV Windows finalizer"

# Evita Fast Startup/hibernação, importante para passthrough de GPU.
powercfg.exe /h off

# Expande C: somente quando o Windows informar que existe espaço contíguo seguro.
try {
    $partition = Get-Partition -DriveLetter C
    $supported = Get-PartitionSupportedSize -DriveLetter C
    if ($supported.SizeMax -gt ($partition.Size + 10MB)) {
        Resize-Partition -DriveLetter C -Size $supported.SizeMax
        Write-Host "C: expandido."
    }
    else {
        Write-Host "C: já está no máximo suportado ou há outra partição bloqueando a expansão."
    }
}
catch {
    Write-Warning "Expansão do C: ignorada: $($_.Exception.Message)"
}
