#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

echo "=== AlexHV v0.3.2 / Plano ==="
gpu="$(select_gpu)"
echo
echo "[GPU]"
for fn in $(slot_functions "$gpu"); do
  echo "$fn -> IOMMU $(iommu_group_for_bdf "$fn" 2>/dev/null || echo NONE)"
  lspci -Dnn -s "$fn"
done

echo
echo "[Audio onboard]"
if [[ -n "${ONBOARD_AUDIO_BDF:-}" ]] && lspci -s "$ONBOARD_AUDIO_BDF" >/dev/null 2>&1; then
  echo "$ONBOARD_AUDIO_BDF -> IOMMU $(iommu_group_for_bdf "$ONBOARD_AUDIO_BDF" 2>/dev/null || echo NONE)"
  lspci -Dnnk -s "$ONBOARD_AUDIO_BDF"
else
  warn "Audio onboard configurado nao foi encontrado."
fi

echo
echo "[Input USB]"
if [[ -n "${INPUT_USB_PORTS:-}" ]]; then
  echo "Portas fixadas no config: $INPUT_USB_PORTS"
else
  discover_usb_input_ports || true
fi

echo
echo "[Storage da VM]"
if storage_exists "$VM_STORAGE"; then
  total_kib="$(storage_total_kib "$VM_STORAGE")"
  avail_kib="$(storage_available_kib "$VM_STORAGE")"
  total_gib=$((total_kib/1024/1024))
  avail_gib=$((avail_kib/1024/1024))
  if (( DISK_FIXED_GIB > 0 )); then
    target="$DISK_FIXED_GIB"
    reserve="fixo"
  else
    reserve_percent=$(( (avail_gib * (100-DISK_PERCENT) + 99) / 100 ))
    reserve="$reserve_percent"
    (( reserve < DISK_MIN_HOST_GIB )) && reserve="$DISK_MIN_HOST_GIB"
    target=$((avail_gib-reserve))
  fi
  echo "Storage: $VM_STORAGE"
  echo "Total fisico: ~${total_gib} GiB"
  echo "Disponivel fisico agora: ~${avail_gib} GiB"
  echo "Disco Windows planejado: ${target} GiB"
  echo "Reserva livre planejada: ${reserve} GiB"
fi

echo
info "O plano nao alterou nada."
