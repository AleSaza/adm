#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

APPLY=0
has_arg --apply "$@" && APPLY=1

[[ "${STORAGE_LAYOUT:-single-local}" == "single-local" ]] || {
  info "STORAGE_LAYOUT nao e single-local; nada a fazer."
  exit 0
}
[[ "${CONSOLIDATE_STORAGE:-1}" == "1" ]] || {
  info "CONSOLIDATE_STORAGE=0; nada a fazer."
  exit 0
}

require_cmd lvs
require_cmd vgs
require_cmd findmnt
require_cmd pvesm

LOCAL_STORAGE_ID="${LOCAL_STORAGE_ID:-local}"
LOCAL_LVM_STORAGE_ID="${LOCAL_LVM_STORAGE_ID:-local-lvm}"
LOCAL_DIR="${LOCAL_DIR:-/var/lib/vz}"
LOCAL_CONTENT="${LOCAL_CONTENT:-images,iso,vztmpl,backup,rootdir,snippets,import}"
LOCAL_IMAGE_FORMAT="${LOCAL_IMAGE_FORMAT:-qcow2}"

root_lv="/dev/pve/root"
data_lv="/dev/pve/data"

[[ -e "$root_lv" ]] || die "LV root esperado nao encontrado: $root_lv"

storage_cfg_exists(){
  grep -Eq "^[[:space:]]*(dir|lvmthin|lvm|zfspool):[[:space:]]+$1([[:space:]]|$)" /etc/pve/storage.cfg 2>/dev/null
}

local_lvm_referenced(){
  grep -Rqs --include='*.conf' "${LOCAL_LVM_STORAGE_ID}:" /etc/pve/qemu-server /etc/pve/lxc 2>/dev/null
}

local_lvm_has_volumes(){
  storage_cfg_exists "$LOCAL_LVM_STORAGE_ID" || return 1
  local n
  n="$(pvesm list "$LOCAL_LVM_STORAGE_ID" 2>/dev/null | awk 'NR>1 && NF{n++} END{print n+0}')"
  (( n > 0 ))
}

thin_data_used(){
  lvs --noheadings -o data_percent pve/data 2>/dev/null | tr -d ' ' | awk 'NF{print; exit}'
}

fs_type="$(findmnt -n -o FSTYPE /)"
vg_free_b="$(vgs --noheadings --units b --nosuffix -o vg_free pve 2>/dev/null | tr -d ' ' | awk 'NF{printf "%.0f",$1;exit}')"
[[ "$vg_free_b" =~ ^[0-9]+$ ]] || vg_free_b=0

printf '=== AlexHV / Storage single-local ===\n'
echo "Layout desejado: um unico storage local em $LOCAL_DIR"
echo "Filesystem raiz: $fs_type"
echo "Conteudos local: $LOCAL_CONTENT"
echo "Formato padrao VM image: $LOCAL_IMAGE_FORMAT"
echo

if [[ -e "$data_lv" ]]; then
  echo "Thin-pool detectado: $data_lv"
  used="$(thin_data_used || true)"
  echo "Data percent informado pelo LVM: ${used:-desconhecido}%"

  if local_lvm_referenced; then
    die "Existem VMs/CTs referenciando ${LOCAL_LVM_STORAGE_ID}. Migre/remova os discos antes. O script NAO vai apagar o thin-pool."
  fi
  if local_lvm_has_volumes; then
    die "${LOCAL_LVM_STORAGE_ID} contem volumes. O script NAO vai apagar dados existentes."
  fi

  warn "No --apply, o LV pve/data sera APAGADO e todo o espaco livre sera entregue ao pve/root."
else
  ok "pve/data ja nao existe."
fi

if (( vg_free_b > 1048576 )); then
  echo "Ha espaco livre no VG pve que sera incorporado ao root."
else
  info "Nao ha extents livres relevantes no VG neste momento."
fi

echo
if ((!APPLY)); then
  info "Dry-run. Nada foi alterado. Use --apply apenas em instalacao limpa/sem discos no local-lvm."
  exit 0
fi

# Remover a definicao do storage antes de remover o LV fisico.
if storage_cfg_exists "$LOCAL_LVM_STORAGE_ID"; then
  pvesm remove "$LOCAL_LVM_STORAGE_ID"
  ok "Storage config ${LOCAL_LVM_STORAGE_ID} removida."
fi

if [[ -e "$data_lv" ]]; then
  lvremove -y "$data_lv"
  ok "Thin-pool pve/data removido."
fi

# Recalcular free extents depois da remocao do thin-pool.
vg_free_b="$(vgs --noheadings --units b --nosuffix -o vg_free pve 2>/dev/null | tr -d ' ' | awk 'NF{printf "%.0f",$1;exit}')"
[[ "$vg_free_b" =~ ^[0-9]+$ ]] || vg_free_b=0
if (( vg_free_b > 1048576 )); then
  lvextend -l +100%FREE "$root_lv"
  case "$fs_type" in
    ext4) resize2fs /dev/mapper/pve-root ;;
    xfs)  xfs_growfs / ;;
    *) die "Filesystem $fs_type nao suportado para grow automatico." ;;
  esac
  ok "pve/root expandido para usar todo o espaco livre."
fi

mkdir -p "$LOCAL_DIR"/{images,template/iso,template/cache,dump,snippets,private,import}

# O storage 'local' ja existe em instalacoes padrao. Se nao existir, cria.
if ! storage_cfg_exists "$LOCAL_STORAGE_ID"; then
  pvesm add dir "$LOCAL_STORAGE_ID" --path "$LOCAL_DIR"
fi

# Proxmox atual oferece estes tipos no backend Directory.
# A opcao import aparece nas versoes atuais; se a versao local a rejeitar,
# abortamos para nao mascarar uma configuracao incompleta.
pvesm set "$LOCAL_STORAGE_ID" --content "$LOCAL_CONTENT" --format "$LOCAL_IMAGE_FORMAT"

ok "Storage $LOCAL_STORAGE_ID habilitado para: $LOCAL_CONTENT"
echo
pvesm status
df -h /
echo
ok "Consolidacao concluida. VM_STORAGE deve ser '$LOCAL_STORAGE_ID'."
