#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1

[[ "$(cpu_vendor)" == "GenuineIntel" ]] || die "Esta versao e somente para CPU Intel."
if iommu_active; then
  ok "IOMMU ja esta ativo; nenhuma alteracao de boot e necessaria."
  exit 0
fi

PARAMS="intel_iommu=on iommu=pt"
warn "IOMMU nao esta ativo. Precisamos adicionar: $PARAMS"

if [[ -f /etc/kernel/cmdline ]]; then
  CURRENT="$(cat /etc/kernel/cmdline)"; NEW="$CURRENT"
  for p in $PARAMS; do grep -qw "$p" <<<"$NEW" || NEW="$NEW $p"; done
  echo "Atual: $CURRENT"; echo "Novo: $NEW"
  if ((!APPLY)); then info "Dry-run. Use --apply e depois reinicie."; exit 0; fi
  cp -a /etc/kernel/cmdline "$STATE_DIR/kernel-cmdline.backup.$(date +%s)"
  printf '%s\n' "$NEW" > /etc/kernel/cmdline
  proxmox-boot-tool refresh
else
  FILE=/etc/default/grub
  [[ -f "$FILE" ]] || die "Configuracao de boot nao suportada."
  LINE="$(grep '^GRUB_CMDLINE_LINUX_DEFAULT=' "$FILE" | head -1 || true)"
  CURRENT="${LINE#*=}"; CURRENT="${CURRENT%\"}"; CURRENT="${CURRENT#\"}"; NEW="$CURRENT"
  for p in $PARAMS; do grep -qw "$p" <<<"$NEW" || NEW="$NEW $p"; done
  echo "Atual: $CURRENT"; echo "Novo: $NEW"
  if ((!APPLY)); then info "Dry-run. Use --apply e depois reinicie."; exit 0; fi
  cp -a "$FILE" "$STATE_DIR/grub.backup.$(date +%s)"
  sed -i "s|^GRUB_CMDLINE_LINUX_DEFAULT=.*|GRUB_CMDLINE_LINUX_DEFAULT=\"$NEW\"|" "$FILE"
  update-grub
fi
ok "IOMMU preparado. REBOOT necessario antes de continuar."
exit 20
