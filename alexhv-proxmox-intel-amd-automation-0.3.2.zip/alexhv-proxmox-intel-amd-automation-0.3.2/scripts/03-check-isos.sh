#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
storage_exists "$ISO_STORAGE" || die "Storage $ISO_STORAGE nao existe."

echo "=== ISOs em $ISO_STORAGE ==="
pvesm list "$ISO_STORAGE" | grep -E '(^Volid|:iso/)' || true

echo
iso_volume_exists "$ISO_STORAGE" "$WINDOWS_ISO" && ok "$WINDOWS_ISO encontrada." || die "$WINDOWS_ISO ausente."
iso_volume_exists "$ISO_STORAGE" "$VIRTIO_ISO" && ok "$VIRTIO_ISO encontrada." || die "$VIRTIO_ISO ausente."
