#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1
vm_exists "$VMID" || die "VM $VMID nao existe."
vm_is_running "$VMID" && die "Desligue a VM antes de anexar a GPU."

gpu="$(select_gpu)"
mapfile -t funcs < <(slot_functions "$gpu")
((${#funcs[@]})) || die "Nenhuma funcao PCI encontrada para $gpu."

echo "=== GPU AMD passthrough ==="
for fn in "${funcs[@]}"; do
  grp="$(iommu_group_for_bdf "$fn" 2>/dev/null || true)"
  [[ -n "$grp" ]] || die "$fn sem grupo IOMMU."
  echo "$fn | IOMMU $grp"
  lspci -Dnnk -s "$fn"
done

if ((!APPLY)); then info "Dry-run. Use --apply para anexar."; exit 0; fi

for fn in "${funcs[@]}"; do
  if qm config "$VMID" | grep -qF "$fn"; then
    ok "$fn ja esta na configuracao da VM."
    continue
  fi
  idx="$(next_hostpci_index "$VMID")"
  opt="${fn},pcie=1"
  [[ "$fn" == "$gpu" ]] && opt="${opt},x-vga=1"
  qm set "$VMID" --"hostpci${idx}" "$opt"
  ok "$fn anexado como hostpci${idx}."
done
warn "O display virtual continua ativo. Remova-o somente na etapa finalize, depois de validar o driver AMD e o monitor fisico."
