#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1
[[ "${ATTACH_ONBOARD_AUDIO:-0}" == "1" ]] || { info "Audio onboard desabilitado no config."; exit 0; }
vm_exists "$VMID" || die "VM $VMID nao existe."
vm_is_running "$VMID" && die "Desligue a VM antes de anexar audio."
[[ -n "${ONBOARD_AUDIO_BDF:-}" ]] || die "ONBOARD_AUDIO_BDF vazio."
lspci -s "$ONBOARD_AUDIO_BDF" >/dev/null 2>&1 || die "Audio $ONBOARD_AUDIO_BDF nao encontrado."

grp="$(iommu_group_for_bdf "$ONBOARD_AUDIO_BDF" 2>/dev/null || true)"
[[ -n "$grp" ]] || die "Audio onboard sem IOMMU."
mapfile -t members < <(group_members "$grp")
echo "=== Audio onboard ==="
echo "$ONBOARD_AUDIO_BDF | IOMMU $grp"
for m in "${members[@]}"; do lspci -Dnn -s "$m"; done
((${#members[@]}==1)) || die "Grupo IOMMU do audio possui outros devices; nao sera passado automaticamente."

if ((!APPLY)); then info "Dry-run. Use --apply para anexar."; exit 0; fi
if qm config "$VMID" | grep -qF "$ONBOARD_AUDIO_BDF"; then ok "Audio ja anexado."; exit 0; fi
idx="$(next_hostpci_index "$VMID")"
qm set "$VMID" --"hostpci${idx}" "${ONBOARD_AUDIO_BDF},pcie=1"
ok "Audio onboard anexado como hostpci${idx}."
