#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1
vm_exists "$VMID" || die "VM $VMID nao existe."
vm_is_running "$VMID" && die "Desligue a VM antes de anexar mouse/teclado."

declare -a ports=()
declare -A descriptions=()

if [[ -n "${INPUT_USB_PORTS:-}" ]]; then
  for p in $INPUT_USB_PORTS; do ports+=("$p"); descriptions["$p"]="configurado manualmente"; done
elif [[ "${AUTO_ATTACH_USB_INPUT:-1}" == "1" ]]; then
  while IFS='|' read -r port desc; do
    [[ -n "$port" ]] || continue
    ports+=("$port")
    descriptions["$port"]="$desc"
  done < <(discover_usb_input_ports)
fi

((${#ports[@]})) || die "Nenhum mouse/teclado USB detectado. Defina INPUT_USB_PORTS no config se necessario."

echo "=== Mouse/teclado USB ==="
for p in "${ports[@]}"; do echo "$p -> ${descriptions[$p]}"; done
echo
warn "As portas fisicas acima serao entregues ao Windows enquanto a VM estiver ligada."

if ((!APPLY)); then info "Dry-run. Use --apply para anexar."; exit 0; fi

for p in "${ports[@]}"; do
  if qm config "$VMID" | grep '^usb[0-9]\+:' | grep -qF "host=$p"; then
    ok "Porta $p ja anexada."
    continue
  fi
  idx="$(next_usb_index "$VMID")"
  qm set "$VMID" --"usb${idx}" "host=${p}"
  ok "Porta $p anexada como usb${idx}."
done
