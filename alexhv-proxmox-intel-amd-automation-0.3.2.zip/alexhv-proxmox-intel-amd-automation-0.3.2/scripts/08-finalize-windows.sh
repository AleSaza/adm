#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1
vm_exists "$VMID" || die "VM $VMID nao existe."

gpu="$(select_gpu)"
qm config "$VMID" | grep -qF "$gpu" || die "GPU AMD $gpu ainda nao esta anexada. Rode a etapa hardware."

if [[ "${REMOVE_VIRTUAL_DISPLAY_ON_FINALIZE:-1}" == "1" ]]; then
  qm config "$VMID" | grep -Eq '^usb[0-9]+:' || die "Nenhum mouse/teclado USB foi anexado. Nao vou remover o display virtual sem input local."
fi

echo "=== Finalizacao AlexHV ==="
echo "- tentar expandir C: via QEMU Guest Agent: ${AUTO_EXPAND_C:-1}"
echo "- desabilitar Fast Startup/hibernacao: ${DISABLE_WINDOWS_FAST_STARTUP:-1}"
echo "- ejetar ISOs: ${EJECT_INSTALL_MEDIA_ON_FINALIZE:-1}"
echo "- remover display virtual/noVNC: ${REMOVE_VIRTUAL_DISPLAY_ON_FINALIZE:-1}"
echo "- autostart: ${AUTO_START:-1}"
echo
warn "So aplique depois de validar a RX 580 no Windows e no monitor fisico."

if ((!APPLY)); then info "Dry-run. Use --apply para finalizar."; exit 0; fi

# Otimizacoes no guest enquanto ele ainda esta ligado.
if vm_is_running "$VMID"; then
  if qm guest cmd "$VMID" ping >/dev/null 2>&1; then
    ok "QEMU Guest Agent respondeu."
    if [[ "${DISABLE_WINDOWS_FAST_STARTUP:-1}" == "1" ]]; then
      qm guest exec "$VMID" -- "C:\\Windows\\System32\\powercfg.exe" /h off >/dev/null || warn "Nao consegui desabilitar hibernacao/Fast Startup."
    fi
    if [[ "${AUTO_EXPAND_C:-1}" == "1" ]]; then
      PS='$ErrorActionPreference="Stop"; try { $p=Get-Partition -DriveLetter C; $s=Get-PartitionSupportedSize -DriveLetter C; if($s.SizeMax -gt ($p.Size + 10485760)){ Resize-Partition -DriveLetter C -Size $s.SizeMax; Write-Output "C_EXPANDED" } else { Write-Output "C_ALREADY_MAX_OR_BLOCKED" } } catch { Write-Output ("C_EXPAND_SKIPPED: " + $_.Exception.Message) }'
      qm guest exec "$VMID" -- "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "$PS" || warn "Expansao automatica do C: foi ignorada."
    fi
  else
    warn "QEMU Guest Agent nao respondeu; pulando ajustes dentro do Windows."
  fi

  info "Desligando Windows de forma limpa..."
  qm shutdown "$VMID" --timeout 120 || die "Windows nao desligou dentro do timeout."
  for _ in $(seq 1 30); do vm_is_running "$VMID" || break; sleep 2; done
  vm_is_running "$VMID" && die "VM ainda esta rodando; nao vou alterar display/boot."
fi

if [[ "${EJECT_INSTALL_MEDIA_ON_FINALIZE:-1}" == "1" ]]; then
  qm config "$VMID" | grep -q '^ide2:' && qm set "$VMID" --delete ide2 || true
  qm config "$VMID" | grep -q '^sata1:' && qm set "$VMID" --delete sata1 || true
fi
qm set "$VMID" --boot 'order=scsi0'

if [[ "${REMOVE_VIRTUAL_DISPLAY_ON_FINALIZE:-1}" == "1" ]]; then
  qm set "$VMID" --vga none
  ok "Display virtual removido; noVNC nao sera mais a saida normal da VM."
fi

if [[ "${AUTO_START:-1}" == "1" ]]; then
  qm set "$VMID" --onboot 1 --startup "order=1,up=${STARTUP_DELAY:-5}"
fi

qm start "$VMID"
ok "Finalizacao concluida. A saida principal agora deve ser a GPU AMD fisica."
