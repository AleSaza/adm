#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1
vm_exists "$VMID" || die "VM $VMID nao existe."
storage_exists "$VM_STORAGE" || die "Storage $VM_STORAGE nao existe."

other_vms="$(qm list | awk -v id="$VMID" 'NR>1 && $1!=id {n++} END{print n+0}')"
if (( other_vms > 0 )); then
  warn "Ha outras VMs neste host. Para evitar overprovision automatico, o grow foi ignorado."
  exit 0
fi

line="$(qm config "$VMID" | grep '^scsi0:' || true)"
[[ -n "$line" ]] || die "scsi0 nao encontrado."
current="$(sed -n 's/.*size=\([0-9]\+\)G.*/\1/p' <<<"$line")"
[[ "$current" =~ ^[0-9]+$ ]] || die "Nao consegui interpretar o tamanho atual de scsi0: $line"

total_kib="$(storage_total_kib "$VM_STORAGE")"
avail_kib="$(storage_available_kib "$VM_STORAGE")"
total_gib=$((total_kib/1024/1024))
avail_gib=$((avail_kib/1024/1024))

if (( DISK_FIXED_GIB > 0 )); then
  target="$DISK_FIXED_GIB"
else
  reserve=$(( (avail_gib * (100-DISK_PERCENT) + 99) / 100 ))
  (( reserve < DISK_MIN_HOST_GIB )) && reserve="$DISK_MIN_HOST_GIB"
  # Cresce apenas com o espaco livre acima da reserva.
  extra=$((avail_gib-reserve))
  (( extra < 0 )) && extra=0
  target=$((current+extra))
fi
(( target >= DISK_MIN_GIB )) || die "Target calculado invalido: ${target} GiB"

echo "=== Grow do disco Windows ==="
echo "Atual:  ${current} GiB"
echo "Target: ${target} GiB"
echo "Reserva livre do host: ${DISK_MIN_HOST_GIB} GiB"

if (( current >= target )); then
  ok "scsi0 ja esta no tamanho alvo ou maior; nada a fazer."
  exit 0
fi

delta=$((target-current))
echo "Crescimento planejado: +${delta}G"
if ((!APPLY)); then info "Dry-run. Use --apply para aumentar scsi0."; exit 0; fi

qm resize "$VMID" scsi0 "+${delta}G"
ok "scsi0 aumentado para aproximadamente ${target} GiB. A expansao de C: sera tentada na finalizacao via Guest Agent."
