#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

echo "=== AlexHV Status ==="
echo "Proxmox: $(pveversion | head -1)"
echo "CPU vendor: $(cpu_vendor)"
iommu_active && ok "IOMMU ativo." || warn "IOMMU nao ativo."
echo
if vm_exists "$VMID"; then
  qm status "$VMID"
  qm config "$VMID"
else
  warn "VM $VMID nao existe."
fi

echo
echo "[USB input detectavel agora]"
discover_usb_input_ports || true
