#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1
vm_exists "$VMID" || die "VM $VMID nao existe."
echo "Restaurar vga: std para recuperar o console noVNC."
if ((!APPLY)); then info "Dry-run. Use --apply."; exit 0; fi
if vm_is_running "$VMID"; then qm shutdown "$VMID" --timeout 120 || die "Nao foi possivel desligar a VM."; fi
qm set "$VMID" --vga std
qm start "$VMID"
ok "Display virtual restaurado."
