#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1
vm_exists "$VMID" || die "VM $VMID nao existe."
vm_is_running "$VMID" && die "Desligue a VM antes de remover USB passthrough."
mapfile -t entries < <(qm config "$VMID" | awk -F: '/^usb[0-9]+:/{print $1}')
if ((${#entries[@]}==0)); then ok "Nenhum usbN configurado."; exit 0; fi
printf 'USBs que serao removidos da VM:\n'; printf '  %s\n' "${entries[@]}"
if ((!APPLY)); then info "Dry-run. Use --apply."; exit 0; fi
for id in "${entries[@]}"; do qm set "$VMID" --delete "$id"; done
ok "USB passthrough removido; os dispositivos voltam ao host."
