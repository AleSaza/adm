#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
CONF="${ALEXHV_CONFIG:-$BASE_DIR/config/alexhv.conf}"
STATE_DIR="/var/lib/alexhv"
mkdir -p "$STATE_DIR"
[[ -f "$CONF" ]] && source "$CONF"

die(){ echo "[ERRO] $*" >&2; exit 1; }
ok(){ echo "[OK] $*"; }
info(){ echo "[..] $*"; }
warn(){ echo "[AVISO] $*" >&2; }
require_root(){ [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Execute como root."; }
require_cmd(){ command -v "$1" >/dev/null 2>&1 || die "Comando ausente: $1"; }
has_arg(){ local n="$1"; shift || true; for a in "$@"; do [[ "$a" == "$n" ]] && return 0; done; return 1; }

cpu_vendor(){ lscpu | awk -F: '/Vendor ID/{gsub(/^[ \t]+/,"",$2);print $2;exit}'; }
iommu_active(){ [[ -d /sys/kernel/iommu_groups ]] && find /sys/kernel/iommu_groups -mindepth 1 -maxdepth 1 -type d 2>/dev/null | grep -q .; }

amd_display_gpus(){
  lspci -Dnn | awk 'BEGIN{IGNORECASE=1} /\[1002:/ && ($0 ~ /VGA compatible controller/ || $0 ~ /3D controller/ || $0 ~ /Display controller/) {print $1}'
}

select_gpu(){
  if [[ -n "${GPU_BDF:-}" ]]; then echo "$GPU_BDF"; return; fi
  mapfile -t gpus < <(amd_display_gpus)
  if [[ ${#gpus[@]} -eq 1 ]]; then echo "${gpus[0]}"; return; fi
  if [[ ${#gpus[@]} -eq 0 ]]; then die "Nenhuma GPU AMD de video detectada."; fi
  printf 'GPUs AMD detectadas:\n' >&2; printf '  %s\n' "${gpus[@]}" >&2
  die "Defina GPU_BDF em $CONF."
}

slot_functions(){
  local gpu="$1" slot="${1%.*}"
  lspci -Dnn | awk -v slot="$slot" '$1 ~ ("^" slot "\\.") {print $1}'
}

iommu_group_for_bdf(){
  local bdf="$1" link="/sys/bus/pci/devices/$1/iommu_group"
  [[ -L "$link" ]] || return 1
  basename "$(readlink -f "$link")"
}

group_members(){
  local group="$1" dir="/sys/kernel/iommu_groups/$1/devices"
  [[ -d "$dir" ]] || return 0
  for d in "$dir"/*; do [[ -e "$d" ]] && basename "$d"; done
}

storage_exists(){ pvesm status --storage "$1" >/dev/null 2>&1; }
storage_total_kib(){ pvesm status --storage "$1" 2>/dev/null | awk 'NR>1{print $4;exit}'; }
storage_available_kib(){ pvesm status --storage "$1" 2>/dev/null | awk 'NR>1{print $6;exit}'; }

iso_volume_exists(){
  local storage="$1" file="$2"
  pvesm list "$storage" 2>/dev/null | awk '{print $1}' | grep -Fxq "${storage}:iso/${file}"
}

next_hostpci_index(){
  local vmid="$1" i
  for i in $(seq 0 15); do
    if ! qm config "$vmid" 2>/dev/null | grep -q "^hostpci${i}:"; then echo "$i"; return 0; fi
  done
  die "Sem slot hostpci livre."
}

next_usb_index(){
  local vmid="$1" i
  for i in $(seq 0 14); do
    if ! qm config "$vmid" 2>/dev/null | grep -q "^usb${i}:"; then echo "$i"; return 0; fi
  done
  die "Sem slot usb livre."
}

usb_port_from_event(){
  local event="$1" p comp
  p="$(readlink -f "/sys/class/input/${event}/device" 2>/dev/null || true)"
  [[ -n "$p" ]] || return 1
  while IFS= read -r comp; do
    if [[ "$comp" =~ ^[0-9]+-[0-9]+([.][0-9]+)*$ ]]; then echo "$comp"; return 0; fi
  done < <(tr '/' '\n' <<<"$p")
  return 1
}

discover_usb_input_ports(){
  require_cmd udevadm
  declare -A labels=()
  local ev props port kind product
  for dev in /dev/input/event*; do
    [[ -e "$dev" ]] || continue
    ev="${dev##*/}"
    props="$(udevadm info --query=property --name="$dev" 2>/dev/null || true)"
    grep -q '^ID_BUS=usb$' <<<"$props" || continue
    kind=""
    grep -q '^ID_INPUT_KEYBOARD=1$' <<<"$props" && kind="keyboard"
    grep -q '^ID_INPUT_MOUSE=1$' <<<"$props" && kind="${kind:+$kind+}mouse"
    [[ -n "$kind" ]] || continue
    port="$(usb_port_from_event "$ev" || true)"
    [[ -n "$port" ]] || continue
    product="$(cat "/sys/bus/usb/devices/$port/product" 2>/dev/null || true)"
    labels["$port"]="${labels[$port]:+${labels[$port]},}$kind${product:+ ($product)}"
  done
  for port in "${!labels[@]}"; do echo "$port|${labels[$port]}"; done | sort
}

vm_is_running(){ [[ "$(qm status "$1" 2>/dev/null | awk '{print $2}')" == "running" ]]; }
vm_exists(){ qm status "$1" >/dev/null 2>&1; }
