#!/usr/bin/env bash
set -Eeuo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Execute como root." >&2; exit 1; }
SRC="$(cd -- "$(dirname -- "$0")" && pwd)"
DST="/opt/alexhv"
mkdir -p "$DST"
cp -a "$SRC"/. "$DST"/
chmod +x "$DST/alexhv.sh" "$DST/install.sh" "$DST/scripts"/*.sh
ln -sfn "$DST/alexhv.sh" /usr/local/sbin/alexhv
echo "[OK] AlexHV instalado em $DST"
echo "Use: alexhv inspect"
