#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
for c in pveversion qm pvesm lspci lscpu udevadm; do require_cmd "$c"; done

echo "=== AlexHV v0.3 / Preflight Intel + AMD ==="
echo "Proxmox: $(pveversion | head -1)"
echo "Kernel:  $(uname -r)"
echo "CPU:     $(lscpu | awk -F: '/Model name/{gsub(/^[ \t]+/,"",$2);print $2;exit}')"
echo "Vendor:  $(cpu_vendor)"
echo "Threads: $(nproc)"
echo "RAM:     $(free -h | awk '/^Mem:/{print $2}')"
echo

[[ "$(cpu_vendor)" == "GenuineIntel" ]] || die "Esta versao aceita somente CPU Intel."
grep -qw vmx /proc/cpuinfo && ok "Intel VT-x (vmx) detectado." || die "VT-x/vmx nao detectado."
if iommu_active; then ok "VT-d/IOMMU ativo."; else warn "IOMMU ainda nao esta ativo."; fi

echo
echo "[GPU AMD]"
mapfile -t gpus < <(amd_display_gpus)
if ((${#gpus[@]})); then
  for gpu in "${gpus[@]}"; do
    echo "GPU: $gpu"
    for fn in $(slot_functions "$gpu"); do
      echo "  $fn | IOMMU $(iommu_group_for_bdf "$fn" 2>/dev/null || echo NONE)"
      lspci -Dnnk -s "$fn" | sed 's/^/    /'
    done
  done
else
  die "Nenhuma GPU AMD encontrada."
fi

echo
echo "[Storages]"; pvesm status
echo
echo "[Bridge]"; ip -br link show "${BRIDGE:-vmbr0}" || true
echo
echo "[Mouse/teclado USB detectados]"
discover_usb_input_ports || true
