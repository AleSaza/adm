#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1

storage_exists "$VM_STORAGE" || die "Storage $VM_STORAGE nao existe."
ip link show "$BRIDGE" >/dev/null 2>&1 || die "Bridge $BRIDGE nao existe."

if vm_exists "$VMID"; then
  ok "VM $VMID ja existe; nao sera recriada."
  qm config "$VMID"
  exit 0
fi

threads="$(nproc)"
reserve_cpu=$(( (threads * (100-CPU_PERCENT) + 99) / 100 ))
(( reserve_cpu < CPU_MIN_HOST_THREADS )) && reserve_cpu="$CPU_MIN_HOST_THREADS"
guest_cpu=$((threads-reserve_cpu))
((guest_cpu>=2)) || die "CPU insuficiente."

total_mib="$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)"
guest_ram=$((total_mib*RAM_PERCENT/100))
(( total_mib-guest_ram < RAM_MIN_HOST_MIB )) && guest_ram=$((total_mib-RAM_MIN_HOST_MIB))
((guest_ram>=4096)) || die "RAM insuficiente."

total_kib="$(storage_total_kib "$VM_STORAGE")"
avail_kib="$(storage_available_kib "$VM_STORAGE")"
total_gib=$((total_kib/1024/1024)); avail_gib=$((avail_kib/1024/1024))
other_vms="$(qm list | awk -v id="$VMID" 'NR>1 && $1!=id {n++} END{print n+0}')"
if ((DISK_FIXED_GIB>0)); then
  disk_gib="$DISK_FIXED_GIB"
elif ((other_vms==0)); then
  disk_gib=$((total_gib-DISK_RESERVE_GIB))
else
  disk_gib=$((avail_gib-DISK_RESERVE_GIB))
fi
((disk_gib>=DISK_MIN_GIB)) || die "Disco calculado muito pequeno: ${disk_gib} GiB."

win_iso="${ISO_STORAGE}:iso/${WINDOWS_ISO}"
virtio_iso="${ISO_STORAGE}:iso/${VIRTIO_ISO}"

echo "=== Criacao da VM ==="
echo "VMID: $VMID | $VM_NAME"
echo "CPU: $guest_cpu/$threads threads"
echo "RAM: $guest_ram/$total_mib MiB"
echo "Disco: ${disk_gib} GiB em $VM_STORAGE"
echo "Storage total: ~${total_gib} GiB | disponivel: ~${avail_gib} GiB"
echo "Windows ISO: $win_iso"
echo "VirtIO ISO: $virtio_iso"
echo "Display inicial: std (noVNC disponivel ate a finalizacao)"

if ((!APPLY)); then info "Dry-run. Use --apply para criar."; exit 0; fi

qm create "$VMID" --name "$VM_NAME" --ostype win11 --machine q35 --bios ovmf \
  --cpu host --cores "$guest_cpu" --memory "$guest_ram" --balloon 0 \
  --scsihw virtio-scsi-single --net0 "virtio,bridge=$BRIDGE" \
  --agent enabled=1 --tablet 1 --vga std
qm set "$VMID" --efidisk0 "${VM_STORAGE}:1,efitype=4m,pre-enrolled-keys=1"
qm set "$VMID" --tpmstate0 "${VM_STORAGE}:1,version=v2.0"
qm set "$VMID" --scsi0 "${VM_STORAGE}:${disk_gib},iothread=1,ssd=1,discard=on"
qm set "$VMID" --ide2 "${win_iso},media=cdrom"
qm set "$VMID" --sata1 "${virtio_iso},media=cdrom"
qm set "$VMID" --boot "order=ide2;scsi0"
ok "VM $VMID criada. Instale o Windows e o pacote virtio-win-guest-tools.exe antes da etapa hardware/finalize."
