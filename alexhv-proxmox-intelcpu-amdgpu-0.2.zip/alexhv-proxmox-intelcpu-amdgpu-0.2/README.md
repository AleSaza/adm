# AlexHV Proxmox — Intel CPU + AMD GPU — v0.2

Versão corrigida para o hardware físico detectado:

- CPU/plataforma Intel;
- GPU AMD Radeon RX 580 2048SP;
- GPU e áudio HDMI juntos no grupo IOMMU;
- áudio onboard Intel isolado;
- múltiplos controladores USB;
- NVMe e NIC mantidos no host.

## Mudança principal

CPU e GPU são detectadas separadamente:

- Intel CPU -> `intel_iommu=on iommu=pt`
- AMD CPU -> `amd_iommu=on iommu=pt`
- GPU AMD -> vendor PCI `1002`

Se IOMMU já estiver ativo, o script de boot não altera nada por padrão.

## Ordem segura

```bash
./scripts/00-preflight.sh
./scripts/01-scan-hardware.sh
./scripts/02-enable-iommu.sh
./scripts/03-plan-passthrough.sh
```

Os comandos acima são diagnóstico/dry-run.

Depois faça upload de:
- `Win11.iso`
- `virtio-win.iso`

e siga:

```bash
./scripts/04-create-win11-vm.sh
./scripts/04-create-win11-vm.sh --apply

./scripts/05-attach-amd-gpu.sh
./scripts/05-attach-amd-gpu.sh --apply
```

Instale o Windows primeiro mantendo o display virtual.

Depois:

```bash
./scripts/06-attach-onboard-audio.sh
./scripts/06-attach-onboard-audio.sh --apply
./scripts/07-map-usb-controllers.sh
```

Preencha `USB_BDFS` em `config/alexhv.conf` somente após mapear as portas físicas:

```bash
./scripts/08-attach-usb-controllers.sh
./scripts/08-attach-usb-controllers.sh --apply
```

Finalize:

```bash
./scripts/09-enable-autostart.sh --apply
./scripts/10-status.sh
```

O script `11-bind-gpu-vfio-early.sh` é fallback opcional, não etapa normal.
