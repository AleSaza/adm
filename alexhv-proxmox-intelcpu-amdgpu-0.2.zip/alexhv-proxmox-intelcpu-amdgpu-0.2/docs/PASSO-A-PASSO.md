# AlexHV v0.2 — roteiro para o seu hardware

## Hardware observado

- CPU/plataforma: Intel Xeon
- GPU: AMD Radeon RX 580 2048SP
- GPU: `0000:03:00.0`
- áudio HDMI da GPU: `0000:03:00.1`
- áudio onboard Intel: `0000:00:1b.0`
- controladores USB observados:
  - `0000:00:14.0`
  - `0000:00:1a.0`
  - `0000:00:1d.0`
- NVMe e NIC permanecem no host.

## Ordem

```bash
cd /root/alexhv-proxmox-intelcpu-amdgpu-0.2

./scripts/00-preflight.sh
./scripts/01-scan-hardware.sh
./scripts/02-enable-iommu.sh
./scripts/03-plan-passthrough.sh
```

Se `02-enable-iommu.sh` disser que o IOMMU já está ativo, não use `--apply`.

Depois faça upload das ISOs pelo Proxmox:

- `Win11.iso`
- `virtio-win.iso`

Confira:

```bash
./scripts/13-check-isos.sh
```

Crie a VM:

```bash
./scripts/04-create-win11-vm.sh
./scripts/04-create-win11-vm.sh --apply
```

Anexe a GPU:

```bash
./scripts/05-attach-amd-gpu.sh
./scripts/05-attach-amd-gpu.sh --apply
```

Instale o Windows pelo console do Proxmox antes de remover o display virtual.

Depois do Windows funcionar, teste o áudio onboard:

```bash
./scripts/06-attach-onboard-audio.sh
./scripts/06-attach-onboard-audio.sh --apply
```

Mapeie os controladores USB:

```bash
./scripts/07-map-usb-controllers.sh
```

Não passe todos automaticamente. Descubra quais portas físicas pertencem a cada
controlador e mantenha pelo menos um controlador USB no host.

Depois edite:

```text
config/alexhv.conf
```

Exemplo:

```text
USB_BDFS="0000:00:1a.0 0000:00:1d.0"
```

Revise e aplique:

```bash
./scripts/08-attach-usb-controllers.sh
./scripts/08-attach-usb-controllers.sh --apply
```

Autostart:

```bash
./scripts/09-enable-autostart.sh --apply
```

Status geral:

```bash
./scripts/10-status.sh
```

## VFIO precoce

Não use inicialmente.

Somente se a RX 580 continuar presa ao driver `amdgpu` e o Proxmox não conseguir
iniciar a VM com passthrough:

```bash
./scripts/11-bind-gpu-vfio-early.sh
```

Se o dry-run estiver correto:

```bash
./scripts/11-bind-gpu-vfio-early.sh --apply
reboot
```

Rollback:

```bash
./scripts/12-rollback-vfio.sh --apply
reboot
```
