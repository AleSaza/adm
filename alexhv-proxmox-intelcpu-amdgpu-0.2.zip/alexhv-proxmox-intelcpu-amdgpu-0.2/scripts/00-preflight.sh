#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
for c in pveversion qm pvesm lspci lscpu; do require_cmd "$c"; done

echo "=== AlexHV / Proxmox Preflight ==="
echo "Proxmox: $(pveversion | head -1)"
echo "Kernel:  $(uname -r)"
echo "CPU vendor: $(cpu_vendor)"
echo "CPU: $(lscpu | awk -F: '/Model name/{gsub(/^[ \t]+/,"",$2);print $2;exit}')"
echo "Threads: $(nproc)"
echo "RAM: $(free -h | awk '/^Mem:/{print $2}')"
echo

flag="$(virt_flag)"
if [[ -n "$flag" ]] && grep -qw "$flag" /proc/cpuinfo; then
  ok "Virtualizacao de CPU detectada ($flag)."
else
  warn "Flag de virtualizacao nao encontrada."
fi

if iommu_active; then ok "IOMMU ativo."; else warn "IOMMU nao detectado."; fi

echo
echo "[GPU AMD]"
mapfile -t gpus < <(amd_display_gpus)
if ((${#gpus[@]})); then
  for gpu in "${gpus[@]}"; do
    lspci -Dnnk -s "$gpu"
    echo
  done
else
  warn "Nenhuma GPU AMD de video encontrada."
fi

echo "[Storages]"
pvesm status
echo
echo "[Bridge]"
ip -br link show "${BRIDGE:-vmbr0}" 2>/dev/null || warn "Bridge ${BRIDGE:-vmbr0} nao encontrada."
