#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
REPORT="$STATE_DIR/hardware-report.txt"

{
  echo "AlexHV hardware report - $(date -Is)"
  echo "Proxmox: $(pveversion | head -1)"
  echo "Kernel: $(uname -r)"
  echo "CPU vendor: $(cpu_vendor)"
  echo
  echo "===== CPU ====="; lscpu
  echo
  echo "===== RAM ====="; free -h
  echo
  echo "===== STORAGE ====="; pvesm status; lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
  echo
  echo "===== NETWORK ====="; ip -br link
  echo
  echo "===== AMD GPU(S) ====="
  mapfile -t gpus < <(amd_display_gpus)
  for gpu in "${gpus[@]}"; do
    echo "--- GPU $gpu ---"
    lspci -Dnnk -s "$gpu"
    for fn in $(slot_functions "$gpu"); do
      lspci -Dnnk -s "$fn"
      echo "IOMMU group: $(iommu_group_for_bdf "$fn" 2>/dev/null || echo NONE)"
    done
    echo
  done
  echo "===== IOMMU GROUPS ====="
  for g in /sys/kernel/iommu_groups/*; do
    [[ -d "$g" ]] || continue
    echo "Group $(basename "$g")"
    for dev in "$g"/devices/*; do
      [[ -e "$dev" ]] || continue
      lspci -Dnn -s "$(basename "$dev")"
    done
    echo
  done
} | tee "$REPORT"

ok "Relatorio salvo em $REPORT"
