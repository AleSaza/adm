#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

APPLY=0
FORCE=0
has_arg --apply "$@" && APPLY=1
has_arg --force "$@" && FORCE=1

PARAMS="$(iommu_param)"

echo "=== AlexHV IOMMU ==="
echo "CPU: $(cpu_vendor)"
echo "Parametros apropriados: $PARAMS"
echo "Cmdline atual: $(cat /proc/cmdline)"
echo

if iommu_active && (( FORCE == 0 )); then
  ok "IOMMU ja esta ativo e possui grupos. Nenhuma alteracao necessaria."
  echo "Use --force somente se quiser gravar explicitamente os parametros no boot."
  exit 0
fi

if [[ -f /etc/kernel/cmdline ]]; then
  CURRENT="$(cat /etc/kernel/cmdline)"
  NEW="$CURRENT"
  for p in $PARAMS; do grep -qw "$p" <<<"$NEW" || NEW="$NEW $p"; done
  echo "Metodo: /etc/kernel/cmdline + proxmox-boot-tool"
  echo "Atual: $CURRENT"
  echo "Novo:  $NEW"

  if (( APPLY )); then
    cp -a /etc/kernel/cmdline "$STATE_DIR/kernel-cmdline.backup.$(date +%s)"
    printf '%s\n' "$NEW" > /etc/kernel/cmdline
    proxmox-boot-tool refresh
    ok "Boot atualizado. Reinicie o host."
  else
    info "Dry-run. Use --apply se realmente for necessario."
  fi
else
  FILE="/etc/default/grub"
  [[ -f "$FILE" ]] || die "Nao encontrei configuracao de boot suportada."
  LINE="$(grep '^GRUB_CMDLINE_LINUX_DEFAULT=' "$FILE" | head -1 || true)"
  [[ -n "$LINE" ]] || die "GRUB_CMDLINE_LINUX_DEFAULT nao encontrado."
  CURRENT="${LINE#*=}"; CURRENT="${CURRENT%\"}"; CURRENT="${CURRENT#\"}"
  NEW="$CURRENT"
  for p in $PARAMS; do grep -qw "$p" <<<"$NEW" || NEW="$NEW $p"; done

  echo "Metodo: GRUB"
  echo "Atual: $CURRENT"
  echo "Novo:  $NEW"

  if (( APPLY )); then
    cp -a "$FILE" "$STATE_DIR/grub.backup.$(date +%s)"
    sed -i "s|^GRUB_CMDLINE_LINUX_DEFAULT=.*|GRUB_CMDLINE_LINUX_DEFAULT=\"$NEW\"|" "$FILE"
    update-grub
    ok "GRUB atualizado. Reinicie o host."
  else
    info "Dry-run. Use --apply se realmente for necessario."
  fi
fi
