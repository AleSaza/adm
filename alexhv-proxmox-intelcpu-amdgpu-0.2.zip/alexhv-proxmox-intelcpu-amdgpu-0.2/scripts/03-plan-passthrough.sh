#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

echo "=== AlexHV Passthrough Planner ==="
gpu="$(select_gpu)"
echo
echo "[GPU AMD]"
echo "Selecionada: $gpu"
for fn in $(slot_functions "$gpu"); do
  grp="$(iommu_group_for_bdf "$fn" 2>/dev/null || echo NONE)"
  echo "$fn -> IOMMU $grp"
  lspci -Dnn -s "$fn"
done

echo
echo "[AUDIO ONBOARD]"
if [[ -n "${ONBOARD_AUDIO_BDF:-}" ]] && lspci -s "$ONBOARD_AUDIO_BDF" >/dev/null 2>&1; then
  grp="$(iommu_group_for_bdf "$ONBOARD_AUDIO_BDF" 2>/dev/null || echo NONE)"
  echo "$ONBOARD_AUDIO_BDF -> IOMMU $grp"
  lspci -Dnnk -s "$ONBOARD_AUDIO_BDF"
else
  warn "ONBOARD_AUDIO_BDF nao encontrado/definido."
fi

echo
echo "[USB CONTROLLERS]"
while read -r bdf; do
  [[ -n "$bdf" ]] || continue
  grp="$(iommu_group_for_bdf "$bdf" 2>/dev/null || echo NONE)"
  echo "$bdf -> IOMMU $grp"
  lspci -Dnn -s "$bdf"
done < <(lspci -Dnn | awk 'BEGIN{IGNORECASE=1}/USB controller/{print $1}')

echo
echo "[RECOMENDACAO]"
echo "- GPU e funcoes do mesmo slot: candidato WINDOWS"
echo "- Audio onboard isolado: candidato WINDOWS"
echo "- Mantenha pelo menos 1 controlador USB no HOST"
echo "- NIC: HOST / rede VirtIO para a VM"
echo "- NVMe do Proxmox: HOST / disco virtual para a VM"
echo
info "Planner nao alterou nenhum dispositivo."
