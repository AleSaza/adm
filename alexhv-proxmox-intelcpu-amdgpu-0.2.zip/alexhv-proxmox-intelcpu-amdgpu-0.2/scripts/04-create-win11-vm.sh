#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1

: "${VMID:=100}"
: "${VM_NAME:=Windows11-AlexHV}"
: "${VM_STORAGE:=local-lvm}"
: "${ISO_STORAGE:=local}"
: "${WINDOWS_ISO:=Win11.iso}"
: "${VIRTIO_ISO:=virtio-win.iso}"
: "${BRIDGE:=vmbr0}"
: "${CPU_PERCENT:=90}"
: "${CPU_MIN_HOST_THREADS:=2}"
: "${RAM_PERCENT:=90}"
: "${RAM_MIN_HOST_MIB:=4096}"
: "${DISK_PERCENT:=90}"
: "${DISK_MIN_FREE_GIB:=32}"
: "${DISK_MIN_GIB:=64}"
: "${DISK_GIB:=0}"

storage_exists "$VM_STORAGE" || die "Storage de VM nao existe: $VM_STORAGE"
storage_exists "$ISO_STORAGE" || die "Storage de ISO nao existe: $ISO_STORAGE"
ip link show "$BRIDGE" >/dev/null 2>&1 || die "Bridge nao existe: $BRIDGE"
qm status "$VMID" >/dev/null 2>&1 && die "VMID $VMID ja existe."

threads="$(nproc)"
reserve_cpu=$(( (threads * (100-CPU_PERCENT) + 99) / 100 ))
(( reserve_cpu < CPU_MIN_HOST_THREADS )) && reserve_cpu="$CPU_MIN_HOST_THREADS"
guest_cpu=$(( threads - reserve_cpu ))
(( guest_cpu < 2 )) && die "CPU insuficiente para Windows 11."

total_mib="$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)"
guest_ram=$(( total_mib * RAM_PERCENT / 100 ))
reserve_ram=$(( total_mib - guest_ram ))
(( reserve_ram < RAM_MIN_HOST_MIB )) && guest_ram=$(( total_mib - RAM_MIN_HOST_MIB ))
(( guest_ram < 4096 )) && die "RAM insuficiente."

if (( DISK_GIB > 0 )); then
  disk_gib="$DISK_GIB"
else
  avail_kib="$(storage_available_kib "$VM_STORAGE")"
  [[ "$avail_kib" =~ ^[0-9]+$ ]] || die "Nao consegui ler espaco de $VM_STORAGE."
  avail_gib=$(( avail_kib / 1024 / 1024 ))
  by_percent=$(( avail_gib * DISK_PERCENT / 100 ))
  by_reserve=$(( avail_gib - DISK_MIN_FREE_GIB ))
  disk_gib="$by_percent"
  (( by_reserve < disk_gib )) && disk_gib="$by_reserve"
  (( disk_gib < DISK_MIN_GIB )) && die "Storage insuficiente. Calculado ${disk_gib} GiB."
fi

win_iso="${ISO_STORAGE}:iso/${WINDOWS_ISO}"
virtio_iso="${ISO_STORAGE}:iso/${VIRTIO_ISO}"

echo "=== Plano da VM Windows 11 ==="
echo "VMID: $VMID"
echo "Nome: $VM_NAME"
echo "CPU guest: $guest_cpu / $threads threads"
echo "RAM guest: $guest_ram / $total_mib MiB"
echo "Disco: $disk_gib GiB em $VM_STORAGE"
echo "Bridge: $BRIDGE"
echo "Windows ISO: $win_iso ($(iso_volume_exists "$ISO_STORAGE" "$WINDOWS_ISO" && echo OK || echo AUSENTE))"
echo "VirtIO ISO:  $virtio_iso ($(iso_volume_exists "$ISO_STORAGE" "$VIRTIO_ISO" && echo OK || echo AUSENTE))"
echo

if ((!APPLY)); then
  info "Dry-run. Use --apply para criar a VM."
  exit 0
fi

qm create "$VMID" \
  --name "$VM_NAME" \
  --ostype win11 \
  --machine q35 \
  --bios ovmf \
  --cpu host \
  --cores "$guest_cpu" \
  --memory "$guest_ram" \
  --balloon 0 \
  --scsihw virtio-scsi-single \
  --net0 "virtio,bridge=$BRIDGE" \
  --agent enabled=1 \
  --tablet 1 \
  --vga std

qm set "$VMID" --efidisk0 "${VM_STORAGE}:1,efitype=4m,pre-enrolled-keys=1"
qm set "$VMID" --tpmstate0 "${VM_STORAGE}:1,version=v2.0"
qm set "$VMID" --scsi0 "${VM_STORAGE}:${disk_gib},iothread=1,ssd=1,discard=on"

boot_items="scsi0"

if iso_volume_exists "$ISO_STORAGE" "$WINDOWS_ISO"; then
  qm set "$VMID" --ide2 "${win_iso},media=cdrom"
  boot_items="ide2;scsi0"
else
  warn "ISO do Windows nao encontrada."
fi

if iso_volume_exists "$ISO_STORAGE" "$VIRTIO_ISO"; then
  qm set "$VMID" --sata1 "${virtio_iso},media=cdrom"
else
  warn "ISO VirtIO nao encontrada."
fi

qm set "$VMID" --boot "order=${boot_items}"

ok "VM $VMID criada."
qm config "$VMID"
