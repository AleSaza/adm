#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1
: "${VMID:=100}"
: "${DISABLE_VIRTUAL_DISPLAY:=0}"

qm status "$VMID" >/dev/null 2>&1 || die "VM $VMID nao existe."
gpu="$(select_gpu)"
mapfile -t funcs < <(slot_functions "$gpu")
((${#funcs[@]})) || die "Nenhuma funcao PCI encontrada para $gpu."

echo "=== Plano GPU AMD ==="
echo "GPU principal: $gpu"
idx=0
for fn in "${funcs[@]}"; do
  grp="$(iommu_group_for_bdf "$fn" 2>/dev/null || true)"
  [[ -n "$grp" ]] || die "$fn nao possui grupo IOMMU."
  echo "hostpci${idx}: $fn | IOMMU=$grp"
  lspci -Dnnk -s "$fn"
  ((idx+=1))
done
echo

if ((!APPLY)); then
  info "Dry-run. Use --apply para anexar a GPU."
  exit 0
fi

[[ "$(qm status "$VMID" | awk '{print $2}')" != "running" ]] || die "Desligue a VM primeiro."

idx=0
for fn in "${funcs[@]}"; do
  opt="${fn},pcie=1"
  [[ "$fn" == "$gpu" ]] && opt="${opt},x-vga=1"
  qm set "$VMID" --"hostpci${idx}" "$opt"
  ((idx+=1))
done

if [[ "$DISABLE_VIRTUAL_DISPLAY" == "1" ]]; then
  qm set "$VMID" --vga none
else
  warn "Display virtual mantido para instalacao e recuperacao."
fi

ok "GPU AMD anexada a VM $VMID."
qm config "$VMID" | grep -E '^(hostpci|vga|machine|bios)'
