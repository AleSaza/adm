#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1
: "${VMID:=100}"
: "${ONBOARD_AUDIO_BDF:=}"

[[ -n "$ONBOARD_AUDIO_BDF" ]] || die "ONBOARD_AUDIO_BDF nao definido."
lspci -s "$ONBOARD_AUDIO_BDF" >/dev/null 2>&1 || die "Dispositivo nao encontrado: $ONBOARD_AUDIO_BDF"
qm status "$VMID" >/dev/null 2>&1 || die "VM $VMID nao existe."

grp="$(iommu_group_for_bdf "$ONBOARD_AUDIO_BDF" 2>/dev/null || true)"
[[ -n "$grp" ]] || die "Audio onboard sem grupo IOMMU."

echo "=== Audio onboard ==="
echo "BDF: $ONBOARD_AUDIO_BDF"
echo "IOMMU: $grp"
lspci -Dnnk -s "$ONBOARD_AUDIO_BDF"
echo
echo "Membros do grupo:"
for m in $(group_members "$grp"); do lspci -Dnn -s "$m"; done

member_count="$(group_members "$grp" | wc -l)"
if (( member_count > 1 )); then
  warn "Grupo possui mais de um dispositivo. Revise antes de aplicar."
fi

if ((!APPLY)); then
  info "Dry-run. Use --apply para anexar."
  exit 0
fi

[[ "$(qm status "$VMID" | awk '{print $2}')" != "running" ]] || die "Desligue a VM primeiro."

next="$(next_hostpci_index "$VMID")"
qm set "$VMID" --"hostpci${next}" "${ONBOARD_AUDIO_BDF},pcie=1"
ok "Audio onboard anexado como hostpci${next}."
