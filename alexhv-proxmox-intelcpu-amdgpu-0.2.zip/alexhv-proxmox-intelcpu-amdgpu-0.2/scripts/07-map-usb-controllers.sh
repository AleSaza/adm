#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root

echo "=== Mapeamento de controladores USB ==="
echo
echo "Controladores PCI:"
while read -r bdf; do
  [[ -n "$bdf" ]] || continue
  grp="$(iommu_group_for_bdf "$bdf" 2>/dev/null || echo NONE)"
  echo
  echo "$bdf | IOMMU $grp"
  lspci -Dnnk -s "$bdf"

  devpath="/sys/bus/pci/devices/$bdf"
  echo "USB buses associados:"
  found=0
  for bus in "$devpath"/usb*; do
    [[ -e "$bus" ]] || continue
    found=1
    echo "  $(basename "$bus")"
  done
  (( found == 0 )) && echo "  (nenhum bus exposto diretamente encontrado)"
done < <(lspci -Dnn | awk 'BEGIN{IGNORECASE=1}/USB controller/{print $1}')

echo
echo "Arvore USB atual:"
lsusb -t || true
echo
echo "Use esta saida para decidir quais controladores podem ir para o Windows."
echo "Mantenha pelo menos um controlador USB no Proxmox."
