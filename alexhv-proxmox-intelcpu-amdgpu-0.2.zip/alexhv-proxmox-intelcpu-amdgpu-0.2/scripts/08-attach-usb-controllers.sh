#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1
: "${VMID:=100}"
: "${USB_BDFS:=}"

[[ -n "$USB_BDFS" ]] || die "USB_BDFS esta vazio. Mapeie primeiro com 07-map-usb-controllers.sh."
qm status "$VMID" >/dev/null 2>&1 || die "VM $VMID nao existe."

echo "=== Controladores USB selecionados ==="
for bdf in $USB_BDFS; do
  lspci -s "$bdf" >/dev/null 2>&1 || die "Dispositivo nao encontrado: $bdf"
  grp="$(iommu_group_for_bdf "$bdf" 2>/dev/null || true)"
  [[ -n "$grp" ]] || die "$bdf sem IOMMU."
  echo "$bdf | IOMMU $grp"
  lspci -Dnnk -s "$bdf"
  echo "Grupo:"
  for m in $(group_members "$grp"); do lspci -Dnn -s "$m"; done
  echo
done

if ((!APPLY)); then
  info "Dry-run. Use --apply somente depois de confirmar as portas fisicas."
  exit 0
fi

[[ "$(qm status "$VMID" | awk '{print $2}')" != "running" ]] || die "Desligue a VM primeiro."

for bdf in $USB_BDFS; do
  next="$(next_hostpci_index "$VMID")"
  qm set "$VMID" --"hostpci${next}" "${bdf},pcie=1"
  ok "$bdf anexado como hostpci${next}."
done
