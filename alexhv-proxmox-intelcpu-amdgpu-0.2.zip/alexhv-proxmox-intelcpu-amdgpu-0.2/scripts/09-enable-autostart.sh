#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1
: "${VMID:=100}"
: "${STARTUP_DELAY:=5}"

qm status "$VMID" >/dev/null 2>&1 || die "VM $VMID nao existe."

echo "VM $VMID sera configurada para iniciar automaticamente."
echo "Delay: ${STARTUP_DELAY}s"

if ((!APPLY)); then
  info "Dry-run. Use --apply."
  exit 0
fi

qm set "$VMID" --onboot 1 --startup "order=1,up=${STARTUP_DELAY}"
ok "Autostart configurado."
