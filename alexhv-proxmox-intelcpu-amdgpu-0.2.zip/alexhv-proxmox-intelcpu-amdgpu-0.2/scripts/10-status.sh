#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
: "${VMID:=100}"

echo "=== AlexHV Status ==="
echo "Proxmox: $(pveversion | head -1)"
echo "Kernel: $(uname -r)"
echo "CPU vendor: $(cpu_vendor)"
echo

if iommu_active; then ok "IOMMU ativo."; else warn "IOMMU nao detectado."; fi

echo
echo "[GPU AMD]"
if gpu="$(select_gpu 2>/dev/null)"; then
  for fn in $(slot_functions "$gpu"); do
    drv="$(basename "$(readlink -f "/sys/bus/pci/devices/$fn/driver" 2>/dev/null)" 2>/dev/null || true)"
    echo "$fn -> driver: ${drv:-none}"
    lspci -Dnn -s "$fn"
  done
else
  warn "GPU AMD nao selecionada."
fi

echo
echo "[AUDIO ONBOARD]"
if [[ -n "${ONBOARD_AUDIO_BDF:-}" ]] && lspci -s "$ONBOARD_AUDIO_BDF" >/dev/null 2>&1; then
  drv="$(basename "$(readlink -f "/sys/bus/pci/devices/$ONBOARD_AUDIO_BDF/driver" 2>/dev/null)" 2>/dev/null || true)"
  echo "$ONBOARD_AUDIO_BDF -> driver: ${drv:-none}"
  lspci -Dnn -s "$ONBOARD_AUDIO_BDF"
fi

echo
echo "[VM]"
if qm status "$VMID" >/dev/null 2>&1; then
  qm status "$VMID"
  qm config "$VMID"
else
  warn "VM $VMID ainda nao existe."
fi
