#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1

gpu="$(select_gpu)"
mapfile -t funcs < <(slot_functions "$gpu")
ids=()

for fn in "${funcs[@]}"; do
  id="$(lspci -nns "$fn" | sed -n 's/.*\[\([0-9a-fA-F]\{4\}:[0-9a-fA-F]\{4\}\)\].*/\1/p' | tail -1)"
  [[ -n "$id" ]] && ids+=("$id")
done

mapfile -t ids < <(printf '%s\n' "${ids[@]}" | awk '!seen[$0]++')
id_csv="$(IFS=,; echo "${ids[*]}")"

echo "=== VFIO precoce OPCIONAL ==="
echo "GPU: $gpu"
printf 'Funcoes:\n'; printf '  %s\n' "${funcs[@]}"
echo "PCI IDs: $id_csv"
warn "Use apenas se o passthrough normal nao conseguir liberar a GPU."
warn "Se esta for a unica GPU, o host ficara sem console grafico apos o boot."

if ((!APPLY)); then
  info "Dry-run. Use --apply somente se realmente necessario."
  exit 0
fi

cat > /etc/modprobe.d/alexhv-vfio.conf <<EOF
options vfio-pci ids=$id_csv
softdep amdgpu pre: vfio-pci
EOF

for m in vfio vfio_iommu_type1 vfio_pci; do
  grep -qxF "$m" /etc/modules || echo "$m" >> /etc/modules
done

update-initramfs -u -k all
ok "VFIO precoce preparado. Reboot necessario."
