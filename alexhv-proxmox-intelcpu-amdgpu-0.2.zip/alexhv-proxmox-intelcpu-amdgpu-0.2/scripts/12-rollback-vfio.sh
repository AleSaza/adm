#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
APPLY=0; has_arg --apply "$@" && APPLY=1

echo "Rollback remove somente a configuracao criada pelo script 11."

if ((!APPLY)); then
  echo "Removeria /etc/modprobe.d/alexhv-vfio.conf"
  echo "Executaria update-initramfs -u -k all"
  info "Dry-run. Use --apply."
  exit 0
fi

rm -f /etc/modprobe.d/alexhv-vfio.conf
update-initramfs -u -k all
ok "Rollback concluido. Reboot recomendado."
