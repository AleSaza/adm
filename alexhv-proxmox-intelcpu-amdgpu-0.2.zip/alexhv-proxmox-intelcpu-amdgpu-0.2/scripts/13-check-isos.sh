#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/_common.sh"
require_root
: "${ISO_STORAGE:=local}"
: "${WINDOWS_ISO:=Win11.iso}"
: "${VIRTIO_ISO:=virtio-win.iso}"

echo "ISOs encontradas em $ISO_STORAGE:"
pvesm list "$ISO_STORAGE" --iso || true
echo
echo "Esperadas:"
echo "  ${ISO_STORAGE}:iso/${WINDOWS_ISO}"
echo "  ${ISO_STORAGE}:iso/${VIRTIO_ISO}"
