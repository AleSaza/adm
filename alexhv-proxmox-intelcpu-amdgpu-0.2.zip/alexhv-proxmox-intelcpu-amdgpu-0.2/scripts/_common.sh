#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
CONF="${ALEXHV_CONFIG:-$BASE_DIR/config/alexhv.conf}"
STATE_DIR="/var/lib/alexhv"
mkdir -p "$STATE_DIR"
[[ -f "$CONF" ]] && source "$CONF"

die(){ echo "[ERRO] $*" >&2; exit 1; }
ok(){ echo "[OK] $*"; }
info(){ echo "[..] $*"; }
warn(){ echo "[AVISO] $*" >&2; }

require_root(){ [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Execute como root."; }
require_cmd(){ command -v "$1" >/dev/null 2>&1 || die "Comando ausente: $1"; }

has_arg(){
  local needle="$1"; shift || true
  for arg in "$@"; do [[ "$arg" == "$needle" ]] && return 0; done
  return 1
}

cpu_vendor(){
  lscpu | awk -F: '/Vendor ID/{gsub(/^[ \t]+/,"",$2);print $2;exit}'
}

virt_flag(){
  case "$(cpu_vendor)" in
    GenuineIntel) echo "vmx" ;;
    AuthenticAMD) echo "svm" ;;
    *) echo "" ;;
  esac
}

iommu_param(){
  case "$(cpu_vendor)" in
    GenuineIntel) echo "intel_iommu=on iommu=pt" ;;
    AuthenticAMD) echo "amd_iommu=on iommu=pt" ;;
    *) die "Fabricante de CPU nao suportado: $(cpu_vendor)" ;;
  esac
}

iommu_active(){
  [[ -d /sys/kernel/iommu_groups ]] &&
  find /sys/kernel/iommu_groups -mindepth 1 -maxdepth 1 -type d 2>/dev/null | grep -q .
}

amd_display_gpus(){
  lspci -Dnn | awk 'BEGIN{IGNORECASE=1}
  /\[1002:/ && ($0 ~ /VGA compatible controller/ || $0 ~ /3D controller/ || $0 ~ /Display controller/) {print $1}'
}

select_gpu(){
  if [[ -n "${GPU_BDF:-}" ]]; then echo "$GPU_BDF"; return; fi
  mapfile -t gpus < <(amd_display_gpus)
  if [[ ${#gpus[@]} -eq 1 ]]; then
    echo "${gpus[0]}"
  elif [[ ${#gpus[@]} -eq 0 ]]; then
    die "Nenhuma GPU AMD detectada."
  else
    printf 'GPUs AMD encontradas:\n' >&2
    printf '  %s\n' "${gpus[@]}" >&2
    die "Defina GPU_BDF em $CONF."
  fi
}

slot_functions(){
  local gpu="$1"
  local slot="${gpu%.*}"
  lspci -Dnn | awk -v slot="$slot" '$1 ~ ("^" slot "\\.") {print $1}'
}

iommu_group_for_bdf(){
  local bdf="$1"
  local link="/sys/bus/pci/devices/$bdf/iommu_group"
  [[ -L "$link" ]] || return 1
  basename "$(readlink -f "$link")"
}

group_members(){
  local group="$1"
  local dir="/sys/kernel/iommu_groups/$group/devices"
  [[ -d "$dir" ]] || return 0
  for d in "$dir"/*; do [[ -e "$d" ]] && basename "$d"; done
}

storage_exists(){ pvesm status --storage "$1" >/dev/null 2>&1; }

storage_available_kib(){
  pvesm status --storage "$1" 2>/dev/null | awk 'NR>1{print $6;exit}'
}

iso_volume_exists(){
  local storage="$1" file="$2"
  pvesm list "$storage" --iso 2>/dev/null |
    awk '{print $1}' | grep -Fxq "${storage}:iso/${file}"
}

next_hostpci_index(){
  local vmid="$1"
  local i
  for i in $(seq 0 15); do
    if ! qm config "$vmid" 2>/dev/null | grep -q "^hostpci${i}:"; then
      echo "$i"
      return 0
    fi
  done
  die "Nao ha slot hostpci livre entre 0 e 15."
}
